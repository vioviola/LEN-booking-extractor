// contentScript.js
// 注入到目标页面后挂载 __ExtractorRuntime，作为 background 与 lib 提取器之间的桥。
// 依赖：lib/aggregator.js、lib/extractors.js 必须先于本文件注入。

(function () {
  if (self.__ExtractorRuntime) return; // 幂等
  self.__ExtractorRuntime = {
    __waitCache: new Set(),
    /**
     * 等待指定 selector 出现（轮询）。超时返回错误对象。
     * 除 selector 外还接受 fallback 数组：任一命中即算成功。
     * 结果按 selector 缓存，避免同一 frame 内重复等待。
     */
    async waitForSelector(selector, timeoutMs, fallbackSels) {
      if (!selector) return true;
      if (this.__waitCache.has(selector)) return true;
      timeoutMs = timeoutMs || 30000;
      const sels = [selector].concat(fallbackSels || []).filter(Boolean);
      const interval = 200;
      const start = Date.now();
      let invalid = false;
      while (Date.now() - start < timeoutMs) {
        for (const s of sels) {
          try {
            if (document.querySelector(s)) {
              this.__waitCache.add(selector);
              return true;
            }
          } catch (e) {
            invalid = true;
          }
        }
        if (invalid && sels.length === 1) {
          return { error: 'invalid_selector', selector, message: '选择器语法无效' };
        }
        await new Promise((r) => setTimeout(r, interval));
      }
      return { error: 'selector_timeout', selector };
    },

    /**
     * 在自己的 document 里找表格，返回 { ok, headers, rowCount, sample, matched } 或 { ok:false }。
     */
    probeHere(tableSelector) {
      if (!self.Extractors) return { ok: false, reason: 'extractors_not_loaded' };
      const hit = self.Extractors.probeTable(document, tableSelector);
      if (!hit || !hit.table || !hit.rows || hit.rows.length === 0) {
        return { ok: false, reason: 'no_rows' };
      }
      const split = self.Extractors.splitHeaderAndRows(hit.table);
      if (!split.headers || split.headers.length === 0) {
        return { ok: false, reason: 'no_headers' };
      }
      return {
        ok: true,
        headers: split.headers,
        rowCount: split.dataRows.length,
        sample: split.dataRows.slice(0, 3),
        matched: self.Extractors.describeElement(hit.table),
      };
    },

    /**
     * 本 frame 是否有内容（用于挑出「有货」的 frame，跳过空白 about:blank 桥页）。
     * 传入 expectedColumns（预设里配的列名）时，额外报告本 frame 最佳表格的表头命中情况 ——
     * 这比单纯数 table 数量可靠得多：目标平台 外壳页自己也可能有 grid，
     * 但不会出现 Project / MD / MD Confirm / Year Month 这些列。
     */
    frameSignal(opts) {
      try {
        const o = opts || {};
        const expected = (o.expectedColumns || []).filter(Boolean);
        const text = (document.body && (document.body.innerText || document.body.textContent)) || '';
        const sig = {
          url: (document.location && document.location.href) || '',
          title: document.title || '',
          textLength: text.trim().length,
          tableCount: document.querySelectorAll('table').length,
          roleRowCount: document.querySelectorAll('[role="row"]').length,
          bodyLength: document.body ? (document.body.innerHTML || '').length : 0,
          headerHits: 0,
          matchedColumns: [],
          bestRows: 0,
        };

        if (expected.length > 0 && self.Extractors) {
          const hit = self.Extractors.probeTable(document, o.tableSelector || '');
          if (hit && hit.table) {
            const split = self.Extractors.splitHeaderAndRows(hit.table);
            const headers = (split.headers || []).map((h) => String(h).trim().toLowerCase());
            sig.headers = split.headers || [];
            sig.bestRows = (split.dataRows || []).length;
            sig.matchedColumns = expected.filter((c) => headers.indexOf(String(c).trim().toLowerCase()) >= 0);
            sig.headerHits = sig.matchedColumns.length;
          }
        }
        return sig;
      } catch (e) {
        return {
          url: '', title: '', textLength: 0, tableCount: 0, roleRowCount: 0,
          bodyLength: 0, headerHits: 0, matchedColumns: [], bestRows: 0,
        };
      }
    },

    /**
     * 检测登录态：title 含 Sign in / contains 登录 input。
     */
    detectLoginPage() {
      const t = (document.title || '').toLowerCase();
      const loginHints = ['sign in', 'log in', '登录', 'login'];
      const url = (location.href || '').toLowerCase();
      const looksLikeLogin =
        loginHints.some((k) => t.includes(k)) ||
        loginHints.some((k) => url.includes(k)) ||
        document.querySelector('input[type="password"]') != null;
      return looksLikeLogin;
    },

    /**
     * 执行提取：等待 selector → 等数据行出现（聚合表）→ 调用 Extractors.run。
     */
    async run(extraction) {
      if (!self.Extractors) return { error: 'extractors_not_loaded' };

      // 已有可用表格时跳过等待，省掉最多 30 秒的轮询
      const already = self.Extractors.probeTable(document, extraction.tableSelector);
      const hasRows = !!(already && already.rows && already.rows.length > 0);

      if (extraction.waitForSelector && !hasRows) {
        const w = await this.waitForSelector(extraction.waitForSelector);
        if (w && w.error) {
          // 等待超时也别急着失败：可能表格就在本 frame，只是 selector 写法不对
          const retry = self.Extractors.probeTable(document, extraction.tableSelector);
          if (!retry || !retry.rows || retry.rows.length === 0) return w;
        }
      }

      // 聚合表专项：Element UI 等拆表结构的「表头表」常先于「表体表」渲染。
      // 若此刻只读得到表头（dataRows=0），先轮询等数据行出现再跑，
      // 否则 findFirstTable 会锁死在只有表头的半个表上，误报 no_data_rows。
      if (extraction.template === 'aggregateTable') {
        const deadline = Date.now() + 15000;
        while (Date.now() < deadline) {
          const probe = self.Extractors.probeTable(document, extraction.tableSelector);
          if (probe && probe.table) {
            const split = self.Extractors.splitHeaderAndRows(probe.table);
            if (split.dataRows && split.dataRows.length > 0) break;
          }
          await new Promise((r) => setTimeout(r, 300));
        }
      }

      return self.Extractors.run(document, extraction);
    },

    /**
     * 探测表格结构（首次配置向导 / 诊断用）
     *
     * 不能「等到任意表格出现就开跑只探一次」——两种真实竞态（2026-09-29 线上复现）：
     *   ① Element UI 的表头表先于表体表渲染，等到了表头立刻探测会拿到
     *      rowCount=0 的「假成功」（或者根本还没表 → no_table_found）；
     *   ② Dynamics 等重外壳页里 webresource iframe 出现/渲染得很晚，
     *      探测那一瞬间 frame 里还没有任何表格。
     * 因此：在 timeoutMs 总预算内轮询 inspectTable，直到读到
     * 「列头 + 至少 1 行数据」为止；预算耗尽才把最后一次结果交给上层
     * （保证「真的没有数据行的表」仍能返回 rowCount=0 而不是死循环）。
     */
    async inspect(tableSelector, waitForSelector, timeoutMs, expectedColumns) {
      if (!self.Extractors) return { error: 'extractors_not_loaded' };

      const budget = timeoutMs || 20000;
      const start = Date.now();
      const waitSel = waitForSelector || 'table, [role="grid"], [role="table"], [role="row"]';
      const fallbacks = ['table', '[role="grid"]', '[role="row"]'];
      const w = await this.waitForSelector(waitSel, budget, fallbacks);
      const waited = { waitForSelector: waitSel, timedOut: !!(w && w.error), waitError: (w && w.error) || null };

      // 期望列名（编辑器下拉已选/预设已存的列名）：页面常有多个表格组
      // （明细表 + 汇总表），先渲染好的那个不一定是对的吧 —— 有期望列名时，
      // 要优先等「列名对得上」的表，不能读到有数据行就锁死。
      const want = (expectedColumns || []).map((s) => String(s).trim().toLowerCase()).filter(Boolean);
      const hitsOf = (r) => {
        if (!r || !Array.isArray(r.headers) || want.length === 0) return 0;
        const hs = r.headers.map((h) => String(h).trim().toLowerCase());
        return want.filter((c) => hs.indexOf(c) >= 0).length;
      };
      const readable = (r) => r && !r.error
        && Array.isArray(r.headers) && r.headers.length > 0
        && (r.rowCount || 0) > 0;
      // 收货打分：命中列名优先，其次行数（明细表 76 行 vs 汇总表 12 行）
      const scoreOf = (r) => (readable(r) ? hitsOf(r) * 10000 + r.rowCount : -1);

      let last = null;      // 最后一次非错误结果（预算耗尽时的兜底）
      let best = null;      // 目前「最该用」的结果
      let bestScore = -1;
      let result = self.Extractors.inspectTable(document, tableSelector);
      for (;;) {
        if (!result.error) {
          last = result;
          const s = scoreOf(result);
          if (s > bestScore) { best = result; bestScore = s; }
        }
        const now = Date.now() - start;
        // 收货条件：
        //   有期望列名 → 命中 >= min(2, 期望数) 才算找准表
        //   （只命中 1 列不算 —— 明细表和汇总表共有「Year Month」，会锁错）；
        //   无期望列名（全新预设）→ 找到表后再留 3s 升级窗，
        //   期间出现行数更多的表就换，避免锁死在先渲染好的小表上。
        const stop = !!best && (want.length > 0
          ? hitsOf(best) >= Math.min(want.length, 2)
          : now >= Math.min(3000, budget));
        if (stop || now >= budget) break;
        await new Promise((res) => setTimeout(res, 400));
        result = self.Extractors.inspectTable(document, tableSelector);
      }

      const final = best || last || result;
      final.waited = waited;
      // 本 frame 的「有没有货」信号，供 background 判断该用哪个 frame 的结果
      final.frame = { url: location.href, ok: !!final.ok, textLength: (document.body ? (document.body.innerText || '').length : 0) };
      return final;
    },

    /**
     * 页面结构诊断（任何时候都可调用）
     */
    diagnose() {
      if (!self.Extractors) return { error: 'extractors_not_loaded' };
      return self.Extractors.diagnosePage(document);
    },
  };
})();