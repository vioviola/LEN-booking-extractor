// summary.js
// 独立汇总页（新标签页）的逻辑：读取后台写入的汇总结果 → 渲染上下两张表 → 分别导出 Excel。
//
// 数据来源：chrome.storage.local 的 lastSummary（由 background 的 performAggregateMulti 写入）。
// 走 storage 而不是消息通道，是为了「重开标签页/刷新页面仍能看到上次结果」，
// 同时能用 storage.onChanged 做到侧边栏一跑完、本页自动刷新。

(function () {
  'use strict';

  const SD = self.SummaryData;

  function $(sel) { return document.querySelector(sel); }

  function escapeHtml(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function fmtNum(v) {
    if (v == null || v === '') return '—';
    const n = Number(v);
    return isFinite(n) ? n.toFixed(2) : String(v);
  }

  function fmtTime(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    if (isNaN(d.getTime())) return '';
    const p = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
  }

  function fileStamp() {
    const d = new Date();
    const p = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}`;
  }

  function sendMessage(msg) {
    return new Promise((resolve, reject) => {
      try {
        chrome.runtime.sendMessage(msg, (resp) => {
          const err = chrome.runtime.lastError;
          if (err) reject(new Error(err.message));
          else resolve(resp);
        });
      } catch (e) {
        reject(e);
      }
    });
  }

  function setTip(text, kind) {
    const el = $('#tip');
    if (!text) { el.classList.add('hidden'); el.textContent = ''; return; }
    el.textContent = text;
    el.className = 'tip' + (kind === 'error' ? ' error' : '');
    el.classList.remove('hidden');
  }

  // === 状态 ===

  let payload = null;
  let tables = null;

  // 明细表的查看状态（只影响页面显示，不改数据、不影响导出）
  //   filters: 每列一个筛选表达式，'' = 不过滤
  //   sort:    当前排序列与方向，'' = 原始顺序
  const FILTER_KEYS = ['month', 'presetName', 'project', 'mdConfirm', 'md', 'missConfirm'];
  const detailFilters = {};
  FILTER_KEYS.forEach((k) => { detailFilters[k] = ''; });
  const detailSort = { key: '', dir: '' };

  function inputVal(key) {
    const el = FILTER_INPUT[key];
    return String((el && el.value) || '');
  }
  // 逐列筛选框：直接取元素（脚本挂在 body 末尾，DOM 已就绪），key 与明细表列 key 一致
  const FILTER_INPUT = {
    month: $('#fltMonth'),
    presetName: $('#fltPresetName'),
    project: $('#fltProject'),
    mdConfirm: $('#fltMdConfirm'),
    md: $('#fltMd'),
    missConfirm: $('#fltMissConfirm'),
  };

  // === 加载 ===

  async function load() {
    let stored = null;
    try {
      const d = await chrome.storage.local.get(SD.SUMMARY_KEY);
      stored = d[SD.SUMMARY_KEY] || null;
    } catch (e) {
      setTip('读取汇总结果失败：' + (e.message || e), 'error');
    }
    payload = stored;
    tables = stored ? SD.buildTables(stored) : null;
    render();
  }

  // === 渲染 ===

  function render() {
    const hasData = !!payload;

    $('#emptyState').classList.toggle('hidden', hasData);
    $('#main').classList.toggle('hidden', !hasData);
    $('#btnRerun').disabled = !hasData || !(tables && tables.presetIds.length);

    if (!hasData) {
      $('#headMeta').textContent = '';
      document.title = '多源汇总 · Booking抓取助手';
      return;
    }

    const monthText = tables.month ? tables.month : '全部月份';
    document.title = `多源汇总 ${monthText}`;

    const meta = [`月份：${monthText}`];
    if (tables.generatedAt) meta.push('生成于 ' + fmtTime(tables.generatedAt));
    meta.push(`源：${tables.okSourceCount}/${tables.sourceCount} 成功`);
    $('#headMeta').textContent = meta.join('　|　');

    renderKpi();
    renderFailBox();
    renderSummaryTable();
    renderDetailTable();
  }

  function renderKpi() {
    const t = tables.totals;
    const cards = [
      { label: 'MD Confirm 合计', value: fmtNum(t.mdConfirm) },
      { label: 'MD 合计', value: fmtNum(t.md) },
      { label: '少confirm MD 合计', value: fmtNum(t.missConfirm), warn: t.missConfirm > 0 },
      { label: '明细行数', value: String(t.detailRows) },
      { label: '成功源', value: `${t.okSourceCount}/${t.sourceCount}`, warn: t.okSourceCount < t.sourceCount },
    ];
    $('#kpiRow').innerHTML = cards.map((c) => `
      <div class="kpi${c.warn ? ' warn' : ''}">
        <div class="label">${escapeHtml(c.label)}</div>
        <div class="value">${escapeHtml(c.value)}</div>
      </div>`).join('');
  }

  function renderFailBox() {
    const box = $('#failBox');
    if (!tables.failures.length) {
      box.classList.add('hidden');
      box.innerHTML = '';
      return;
    }
    const items = tables.failures.map((f) => {
      const src = payload.sources.find((s) => (s.name || '') === f.presetName) || {};
      const url = src.url ? ` <span class="fail-url">${escapeHtml(src.url.slice(0, 110))}</span>` : '';
      return `<li><strong>${escapeHtml(f.presetName)}</strong>：${escapeHtml(f.errorText)}${url}</li>`;
    }).join('');
    box.innerHTML = `<div class="fail-head">有 ${tables.failures.length} 个源没有取到数据（下表未计入这些源）</div><ul>${items}</ul>`;
    box.classList.remove('hidden');
  }

  function renderSummaryTable() {
    const tb = $('#summaryTable tbody');
    tb.innerHTML = tables.summaryRows.map((r) => {
      if (!r.ok) {
        return `<tr class="src-fail">
          <td>${escapeHtml(r.month)}</td>
          <td>${escapeHtml(r.presetName)}</td>
          <td class="num">—<div class="cell-note">${escapeHtml(r.errorText)}</div></td>
        </tr>`;
      }
      return `<tr>
        <td>${escapeHtml(r.month)}</td>
        <td>${escapeHtml(r.presetName)}</td>
        <td class="num">${fmtNum(r.mdConfirm)}</td>
      </tr>`;
    }).join('');

    $('#summaryTable tfoot').innerHTML = tables.summaryRows.length
      ? `<tr><td colspan="2">合计</td><td class="num">${fmtNum(tables.totals.mdConfirm)}</td></tr>`
      : '';

    $('#summaryCount').textContent = `${tables.summaryRows.length} 行（每个源 1 行）`;
  }

  function renderDetailTable() {
    renderDetail();
  }

  // 明细表：先按当前筛选保留行，再按当前排序列排序，最后渲染。
  // 与上表不同，这里渲染是可被反复触发的（改筛选、点表头），所以单独拆出来。
  function detailViewRows() {
    if (!tables) return [];
    const filtered = SD.applyFilters(tables.detailRows, detailFilters, SD.DETAIL_COLUMNS);
    return detailSort.key && detailSort.dir
      ? SD.sortRows(filtered, detailSort.key, detailSort.dir, SD.DETAIL_COLUMNS)
      : filtered;
  }

  function missConfirmClass(v) {
    const n = Number(v);
    if (!isFinite(n) || n === 0) return '';
    // 大于 0：还有 MD 没被 confirm → 高亮；小于 0：Confirm 超过 MD，属数据异常 → 红字
    return n > 0 ? ' over' : ' neg';
  }

  function renderDetail() {
    if (!tables) return;

    const rows = detailViewRows();
    const tb = $('#detailTable tbody');

    if (rows.length === 0) {
      tb.innerHTML = `<tr class="no-data"><td colspan="${SD.DETAIL_COLUMNS.length}">没有符合筛选条件的行（点右上「重置筛选/排序」回到全部）</td></tr>`;
    } else {
      tb.innerHTML = rows.map((r) => `
        <tr>
          <td>${escapeHtml(r.month)}</td>
          <td>${escapeHtml(r.presetName)}</td>
          <td>${escapeHtml(r.project)}</td>
          <td class="num">${fmtNum(r.mdConfirm)}</td>
          <td class="num">${fmtNum(r.md)}</td>
          <td class="num${missConfirmClass(r.missConfirm)}">${fmtNum(r.missConfirm)}</td>
        </tr>`).join('');
    }

    // 表脚合计按**当前可见行**重算（筛选后看合计才有意义），并说明这是筛选后的口径
    const sums = SD.sumRows(rows);
    const filtered = rows.length !== tables.detailRows.length;
    $('#detailTable tfoot').innerHTML = rows.length
      ? `<tr>
          <td colspan="3">合计${filtered ? '（筛选后）' : ''}</td>
          <td class="num">${fmtNum(sums.mdConfirm)}</td>
          <td class="num">${fmtNum(sums.md)}</td>
          <td class="num">${fmtNum(sums.missConfirm)}</td>
        </tr>`
      : '';

    const total = tables.detailRows.length;
    $('#detailCount').textContent = filtered
      ? `显示 ${rows.length} / ${total} 行（每个源 × 每个项目 1 行）`
      : `${total} 行（每个源 × 每个项目 1 行）`;

    renderDetailSortMarks();
    renderDetailFilterState(rows, total);
  }

  // 表头排序标记：只有当前排序列带 asc/desc 类，CSS 用 ::after 画箭头
  function renderDetailSortMarks() {
    const ths = document.querySelectorAll('#detailTable th[data-key]');
    Array.prototype.forEach.call(ths, (th) => {
      const key = th.getAttribute('data-key');
      th.classList.toggle('asc', !!detailSort.key && detailSort.key === key && detailSort.dir === 'asc');
      th.classList.toggle('desc', !!detailSort.key && detailSort.key === key && detailSort.dir === 'desc');
    });
  }

  function renderDetailFilterState(rows, total) {
    const active = SD.isFilterActive(detailFilters);
    const sortLabel = detailSort.key
      ? `按「${(SD.DETAIL_COLUMNS.filter((c) => c.key === detailSort.key)[0] || {}).label || detailSort.key}」${detailSort.dir === 'desc' ? '降序' : '升序'}`
      : '';

    // 数值列敲了看不懂的表达式：标红 + 提示它被忽略了（绝不把整表筛空）
    const bad = SD.badNumberFilters(detailFilters, SD.DETAIL_COLUMNS);
    Object.keys(FILTER_INPUT).forEach((k) => {
      const el = FILTER_INPUT[k];
      if (el && el.classList) el.classList.toggle('bad', bad.indexOf(k) >= 0);
    });

    const bits = [];
    if (active) bits.push(`已筛选 ${rows.length}/${total} 行`);
    if (sortLabel) bits.push(sortLabel);
    if (bad.length) bits.push('数值筛选写法无法识别，已忽略（可用 >0 / >=1.5 / <10 / =3）');
    $('#detailFilterState').textContent = bits.join('　|　');
  }

  // === 明细表的筛选与排序交互 ===

  function syncDetailFilters() {
    Object.keys(FILTER_INPUT).forEach((k) => { detailFilters[k] = inputVal(k); });
  }

  // 点表头排序：同一个列再点一次换方向；换列则重置方向。
  // 数值列先降序（先看缺口大的），文本列先升序（先看字典序靠前的）。
  function toggleDetailSort(key) {
    if (!key) return;
    const numeric = (SD.DETAIL_COLUMNS.filter((c) => c.key === key)[0] || {}).type === 'number';
    if (detailSort.key === key) {
      detailSort.dir = detailSort.dir === 'desc' ? 'asc' : 'desc';
    } else {
      detailSort.key = key;
      detailSort.dir = numeric ? 'desc' : 'asc';
    }
    renderDetail();
  }

  function resetDetailView(alsoClearInputs) {
    detailSort.key = '';
    detailSort.dir = '';
    Object.keys(FILTER_INPUT).forEach((k) => {
      detailFilters[k] = '';
      const el = FILTER_INPUT[k];
      if (el && alsoClearInputs !== false) el.value = '';
    });
    renderDetail();
  }

  // 事件委托：表头单元格（含里面的箭头）都能点，筛选行里的输入框没有 data-key、不受影响
  $('#detailTable').addEventListener('click', (e) => {
    const t = e && e.target;
    const th = t && t.closest ? t.closest('th[data-key]') : null;
    if (th) toggleDetailSort(th.getAttribute('data-key'));
  });

  // 输入即筛（只重渲染明细表，不重建输入框，光标与焦点不丢）
  Object.keys(FILTER_INPUT).forEach((k) => {
    const el = FILTER_INPUT[k];
    if (!el) return;
    el.addEventListener('input', () => { syncDetailFilters(); renderDetail(); });
    el.addEventListener('change', () => { syncDetailFilters(); renderDetail(); });
  });

  $('#btnDetailReset').addEventListener('click', () => resetDetailView(true));

  // === 汇总表区域：拖右下角调高（只调高，宽度跟随页面），高度记忆在 localStorage ===
  // 两个坑与侧边栏一样：ResizeObserver 首次观察会立刻回调（等恢复完再存）；
  // 隐藏状态下 offset 为 0（这里 main 未加载时不可见，0 值一律不落盘）。
  const SUM_WRAP_H_KEY = 'summaryTableWrapH';
  (function initSummaryTableResize() {
    const wrap = $('#summaryTableWrap');
    if (!wrap) return;
    let ready = false;
    try {
      const saved = parseInt(localStorage.getItem(SUM_WRAP_H_KEY), 10);
      if (saved > 0) wrap.style.height = saved + 'px';
    } catch (e) { /* localStorage 不可用就不记忆 */ }
    ready = true;

    let timer = null;
    if (typeof ResizeObserver !== 'undefined') {
      new ResizeObserver(() => {
        const h = wrap.offsetHeight;
        if (!ready || !h) return;
        clearTimeout(timer);
        timer = setTimeout(() => {
          try { localStorage.setItem(SUM_WRAP_H_KEY, String(wrap.offsetHeight)); } catch (e) { /* 忽略 */ }
        }, 300);
      }).observe(wrap);
    }
  })();


  // === 导出 Excel ===

  function exportTable(which) {
    if (!payload || !tables) return;
    const isSummary = which === 'summary';
    const columns = isSummary ? SD.SUMMARY_COLUMNS : SD.DETAIL_COLUMNS;

    // 明细表导出「当前排序顺序下的全部行」：**不套用筛选**。
    // 财务文件宁可多几行让人自己剔，也不能因为一个筛选悄悄少几行数字。
    const rows = isSummary
      ? tables.summaryRows
      : (detailSort.key && detailSort.dir
        ? SD.sortRows(tables.detailRows, detailSort.key, detailSort.dir, SD.DETAIL_COLUMNS)
        : tables.detailRows);

    // 失败源没有数值行，导出时也跳过，避免 Excel 里出现空数字
    const dataRows = isSummary ? rows.filter((r) => r.ok) : rows;

    if (dataRows.length === 0) {
      setTip('这张表没有可导出的数据', 'error');
      return;
    }

    const sheetName = isSummary ? '汇总表' : '明细表';
    let bytes;
    try {
      bytes = self.Xlsx.build([{ name: sheetName, columns, rows: dataRows }]);
    } catch (e) {
      setTip('生成 Excel 失败：' + (e.message || e), 'error');
      return;
    }

    const blob = new Blob([bytes], { type: self.Xlsx.XLSX_MIME });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${sheetName}_${tables.month || '全部月份'}_${fileStamp()}.xlsx`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 20000);

    const note = (!isSummary && SD.isFilterActive(detailFilters))
      ? `（全部 ${dataRows.length} 行，含被筛选隐藏的行）`
      : '';
    setTip(`已导出「${sheetName}」：${dataRows.length} 行${note} → ${a.download}`);
  }

  $('#btnExportSummary').addEventListener('click', () => exportTable('summary'));
  $('#btnExportDetail').addEventListener('click', () => exportTable('detail'));

  // === 重新抓取 ===

  // 「预计剩余约 Xs」倒计时（与侧边栏同一策略：保守估算、到 0 停住、结束时掐掉）
  function startEta(totalSeconds, onTick) {
    const startAt = Date.now();
    let stopped = false;
    function tick() {
      if (stopped) return;
      const left = Math.max(0, Math.ceil(totalSeconds - (Date.now() - startAt) / 1000));
      onTick(left);
      setTimeout(tick, 1000);
    }
    onTick(totalSeconds);
    setTimeout(tick, 1000);
    return function stop() { stopped = true; };
  }

  $('#btnRerun').addEventListener('click', async () => {
    if (!tables || !tables.presetIds.length) return;
    const btn = $('#btnRerun');
    btn.disabled = true;
    const stopEta = startEta(tables.presetIds.length * 15, (left) => {
      setTip(`重新抓取中：${tables.presetIds.length} 个源逐个执行，预计剩余约 ${left}s，请勿关闭本页…`);
    });

    try {
      const r = await sendMessage({
        type: 'aggregateMulti',
        presetIds: tables.presetIds,
        month: tables.month,
      });
      stopEta();
      if (!r || r.error) {
        setTip('重新抓取失败：' + SD.friendlyError((r && r.error) || 'unknown'), 'error');
      } else {
        setTip(`重新抓取完成：${r.okSourceCount}/${r.sourceCount} 个源成功`);
      }
    } catch (e) {
      stopEta();
      setTip('重新抓取失败：' + (e.message || e), 'error');
    }

    // background 已把新结果写进 storage，这里重新读一遍（onChanged 也可能已经触发过）
    await load();
    btn.disabled = false;
  });

  $('#btnPrint').addEventListener('click', () => window.print());

  // 侧边栏再跑一次汇总 → 本页自动刷新
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes[SD.SUMMARY_KEY]) load();
    });
  } catch (e) { /* 忽略 */ }

  load();
})();
