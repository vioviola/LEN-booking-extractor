// sidepanel.js
// 侧边栏（Side Panel）UI 逻辑：月份选择、2 标签页、结果展示、与 background 通信
//
// 标签结构（围绕主流程：逐条配置预设 → 多源批量执行）：
//   A 预设任务 —— 列表（新增 / 运行 / 编辑 / 删除）+ 内嵌的预设编辑器
//                 编辑器里含原来那个「聚合表向导」：探测列头 → 点选角色 → 试算 → 保存
//   B 多源汇总 —— 勾选多条同结构预设 → 串行抓取 → 合并 → 打开独立汇总页
//
// 注意：v1.9.0 起把「聚合表向导」和「设置」两个标签并进了预设任务的编辑功能。
// 两套表单拆开会导致「新建走向导、改参数走设置、改列映射又要回向导」来回跳，
// 而且设置页没有列探测能力，改个 URL 就等于把列映射配错。现在一条预设的所有配置
// 都在同一个编辑器里改。

(function () {
  'use strict';

  // === 工具 ===

  function $(sel) { return document.querySelector(sel); }
  function $$(sel) { return Array.from(document.querySelectorAll(sel)); }

  function fmtMonth(ym) {
    if (!ym) return '';
    const [y, m] = ym.split('-');
    return `${y}年${parseInt(m, 10)}月`;
  }
  function currentMonthValue() {
    const d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
  }
  function prevMonthValue(ym) {
    if (!ym) ym = currentMonthValue();
    const [y, m] = ym.split('-').map(Number);
    const d = new Date(y, m - 2, 1);
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
  }

  // 列表里的 URL 只展示 data= 之后的值。
  // 目标平台的 webresource 链接有一百多字符（appid/forceUCI/pagetype/... 全是噪音），
  // 整条铺在列表里既占地方又看不出差别；不同源之间真正不同的就是 data 参数。
  // 值太长时保留头尾、中间打省略号 —— 只留开头的话，前缀相同的两条链接看起来一模一样。
  function truncateMiddle(s, head, tail) {
    const str = String(s || '');
    if (str.length <= head + tail + 1) return str;
    return str.slice(0, head) + '…' + str.slice(-tail);
  }

  function shortUrl(url) {
    const s = String(url || '');
    const i = s.indexOf('data=');
    if (i >= 0) {
      // 值止于下一个参数分隔符：不切的话尾部会串进 &cmdbar=false&navbar=off 之类的噪音
      let v = s.slice(i + 5);
      const end = v.search(/[&#]/);
      if (end >= 0) v = v.slice(0, end);
      return 'data=' + truncateMiddle(v, 20, 14);
    }
    // 没有 data 参数的普通网址：去掉协议头，同样掐中留头尾
    return truncateMiddle(s.replace(/^https?:\/\//i, ''), 26, 12);
  }

  function setStatus(text, kind) {
    const el = $('#resultStatus');
    el.textContent = text || '';
    el.className = '';
    if (kind === 'error') el.style.color = '#c00';
    else if (kind === 'ok') el.style.color = '#2a7';
    else el.style.color = '#888';
  }

  // 运行时的「预计剩余约 Xs」：纯前端倒计时。
  // 后台是逐源串行抓取、前端只发一条消息，拿不到逐源进度，
  // 所以按保守经验值倒计（单源约 30s、每个汇总源约 15s）：
  // 数字只会越数越小、到 0 停住，不会给出误导性的精确值；结束时 stop() 掐掉。
  // 用 setTimeout 链而不是 setInterval：测试沙箱里只垫了 setTimeout。
  function startEta(totalSeconds, onTick) {
    const startAt = Date.now();
    let stopped = false;
    function tick() {
      if (stopped) return;
      const left = Math.max(0, Math.ceil(totalSeconds - (Date.now() - startAt) / 1000));
      onTick(left);
      setTimeout(tick, 1000);
    }
    onTick(totalSeconds);
    setTimeout(tick, 1000);
    return function stop() { stopped = true; };
  }

  function sendMessage(msg) {
    return new Promise((resolve, reject) => {
      try {
        chrome.runtime.sendMessage(msg, (resp) => {
          const err = chrome.runtime.lastError;
          if (err) reject(new Error(err.message));
          else resolve(resp);
        });
      } catch (e) {
        reject(e);
      }
    });
  }

  // === 全局月份 ===

  // 初始化状态（存储里还没存过月份）→ 默认选中本月（v1.14.0）。
  // 只回填显示、不写存储：用户「清除月份」选「全部」的选择依然持久，
  // 但下次打开插件仍是「默认本月」。
  let monthIsDefault = false;

  async function loadGlobalMonth() {
    const r = await sendMessage({ type: 'getGlobalMonth' });
    const v = (r && r.globalMonth) || '';
    monthIsDefault = !v;
    $('#globalMonth').value = v || currentMonthValue();
    updateMonthHint();
  }

  function updateMonthHint() {
    const v = $('#globalMonth').value;
    const hint = $('#monthHint');
    if (!v) hint.textContent = '当前：全部';
    else hint.textContent = '当前：' + fmtMonth(v) + (monthIsDefault ? '（默认本月）' : '');
  }

  async function saveGlobalMonth(v) {
    monthIsDefault = false;   // 用户手动改过/清空后，就不再是「默认」状态
    await sendMessage({ type: 'setGlobalMonth', value: v || '' });
    updateMonthHint();
  }

  $('#globalMonth').addEventListener('change', (e) => saveGlobalMonth(e.target.value));
  $('#btnThisMonth').addEventListener('click', () => {
    $('#globalMonth').value = currentMonthValue();
    saveGlobalMonth($('#globalMonth').value);
  });
  $('#btnPrevMonth').addEventListener('click', () => {
    const v = prevMonthValue($('#globalMonth').value);
    $('#globalMonth').value = v;
    saveGlobalMonth(v);
  });
  $('#btnClearMonth').addEventListener('click', () => {
    $('#globalMonth').value = '';
    saveGlobalMonth('');
  });

  // === 标签切换 ===

  function switchTab(tabName) {
    $$('.tab-btn').forEach((b) => b.classList.toggle('active', b.dataset.tab === tabName));
    $$('.tab-panel').forEach((panel) => panel.classList.toggle('active', panel.dataset.tab === tabName));
  }

  $$('.tab-btn').forEach((btn) => {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
  });

  // === 标签 A：预设任务（列表 + 编辑器两个视图）===

  function showListView() {
    $('#presetListView').classList.remove('hidden');
    $('#presetEditorView').classList.add('hidden');
  }

  function showEditorView() {
    $('#presetListView').classList.add('hidden');
    $('#presetEditorView').classList.remove('hidden');
  }

  // 列表的排序 / 筛选状态（# 列默认升序，点表头切换方向；筛选按列「包含」匹配）
  const listState = {
    sortKey: 'no',
    sortDir: 'asc',
    filters: { no: '', name: '', url: '', status: '' },
  };

  const FILTER_INPUTS = [
    ['#fltNo', 'no'],
    ['#fltName', 'name'],
    ['#fltUrl', 'url'],
    ['#fltStatus', 'status'],
  ];

  function bindListFilterAndSort() {
    FILTER_INPUTS.forEach(([sel, key]) => {
      $(sel).addEventListener('input', (e) => {
        listState.filters[key] = e.target.value || '';
        refreshPresets();
      });
    });
    // 全选框：勾/取消当前筛选结果里的所有行
    $('#selAll').addEventListener('change', (e) => {
      const on = e.target.checked;
      $$('#presetListBody input.row-sel').forEach((cb) => {
        cb.checked = on;
        const id = cb.dataset.id;
        if (on) selectedIds.add(id);
        else selectedIds.delete(id);
      });
      syncSelAll();
      updateSelBar();
    });
    // 点表头排序：同一列再点一次切换方向
    const headRow = $('#presetList thead tr');
    headRow.addEventListener('click', (e) => {
      const th = e.target && e.target.closest ? e.target.closest('th[data-key]') : null;
      if (!th) return;
      const key = th.dataset.key;
      if (listState.sortKey === key) {
        listState.sortDir = listState.sortDir === 'asc' ? 'desc' : 'asc';
      } else {
        listState.sortKey = key;
        listState.sortDir = 'asc';
      }
      refreshPresets();
    });
  }

  // 勾选列：待删除的预设 id 集合（刷新时按现存预设修剪，避免指向已不存在的行）
  const selectedIds = new Set();

  function updateSelBar() {
    const btn = $('#btnDeleteSel');
    const n = selectedIds.size;
    btn.hidden = n === 0;
    btn.textContent = n === 0 ? '' : '删除所选（' + n + '）';
  }

  // 全选框状态 = 当前筛选结果的勾选情况（全勾=✓，部分勾=半选，无=空）
  function syncSelAll() {
    const boxes = $$('#presetListBody input.row-sel');
    const selAll = $('#selAll');
    const checkedCount = boxes.filter((b) => b.checked).length;
    selAll.checked = boxes.length > 0 && checkedCount === boxes.length;
    selAll.indeterminate = checkedCount > 0 && checkedCount < boxes.length;
  }

  $('#btnDeleteSel').addEventListener('click', async () => {
    const ids = Array.from(selectedIds);
    if (ids.length === 0) return;
    if (!confirm('删除所选的 ' + ids.length + ' 条预设任务？此操作不可撤销。')) return;
    for (const id of ids) await sendMessage({ type: 'deletePreset', id });
    selectedIds.clear();
    setStatus('已删除 ' + ids.length + ' 条预设任务', 'ok');
    await refreshPresets();
    await refreshMultiList();
  });

  async function refreshPresets() {
    const r = await sendMessage({ type: 'listPresets' });
    const presets = (r && r.presets) || [];
    const tb = $('#presetListBody');
    tb.innerHTML = '';

    // 勾选集合按现存预设修剪（刚被别处删掉的 id 不再占着「已选」名额）
    const liveIds = new Set(presets.map((p) => p.id));
    Array.from(selectedIds).forEach((id) => { if (!liveIds.has(id)) selectedIds.delete(id); });

    // 注记编号 → 筛选 → 排序（纯函数在 lib/presets.js，编号不因排序错乱）
    const annotated = self.PresetsStore.filterPresets(
      self.PresetsStore.annotatePresets(presets),
      listState.filters
    );
    const sorted = self.PresetsStore.sortPresets(annotated, listState.sortKey, listState.sortDir);

    const visible = sorted.length;
    $('#presetCount').textContent = visible === presets.length
      ? presets.length + ' 条'
      : visible + ' / ' + presets.length + ' 条';
    $('#presetEmpty').classList.toggle('hidden', presets.length > 0);
    if (presets.length > 0 && visible === 0) {
      // 有预设但全被筛掉：给一行提示
      const tr = document.createElement('tr');
      tr.innerHTML = '<td class="col-filter-empty" colspan="6">没有匹配当前筛选的预设</td>';
      tb.appendChild(tr);
    }

    // 表头排序指示箭头
    $$('#presetList thead th[data-key]').forEach((th) => {
      const arrow = th.querySelector('.arrow');
      const active = th.dataset.key === listState.sortKey;
      th.classList.toggle('sorted', active);
      if (arrow) arrow.textContent = active ? (listState.sortDir === 'asc' ? ' ▲' : ' ▼') : '';
    });

    sorted.forEach(({ p, no }) => {
      // 一行 = 一条预设，六列：勾选 / #（可编辑编号）/ 预设名 / URL / 状态 / 功能按钮
      const status = self.PresetsStore.presetStatusOf(p);
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td class="col-sel"><input type="checkbox" class="row-sel" title="勾选以便批量删除" /></td>
        <td class="col-no"><input type="number" class="row-no" min="1" step="1" title="编辑编号" /></td>
        <td class="col-name"><span class="preset-name"></span></td>
        <td class="col-url"><span class="preset-url"></span></td>
        <td class="col-status"><span class="${status === 'OK' ? 'badge-ok' : 'badge-wait'}">${status}</span></td>
        <td class="col-actions">
          <button class="run">运行</button>
          <button class="edit"></button>
          <button class="del">删除</button>
        </td>
      `;
      const selBox = tr.querySelector('.row-sel');
      selBox.dataset.id = p.id;
      selBox.checked = selectedIds.has(p.id);
      selBox.addEventListener('change', () => {
        if (selBox.checked) selectedIds.add(p.id);
        else selectedIds.delete(p.id);
        syncSelAll();
        updateSelBar();
      });
      const noInput = tr.querySelector('.row-no');
      noInput.value = String(no);
      // 编辑编号：写回 preset.no（清空则回到自动编号）。筛选/排序立即生效。
      noInput.addEventListener('change', async () => {
        const v = parseInt(noInput.value, 10);
        const next = Object.assign({}, p);
        if (Number.isFinite(v) && v >= 1) next.no = v;
        else delete next.no;
        await sendMessage({ type: 'upsertPreset', preset: next });
        refreshPresets();
      });
      tr.querySelector('.preset-name').textContent = p.name || '(无名称)';
      tr.querySelector('.edit').textContent = p.needsSetup ? '配置' : '编辑';
      const urlEl = tr.querySelector('.preset-url');
      urlEl.textContent = shortUrl(p.url);
      // 格子里只给截断值，完整 URL 挂在悬停提示上，需要核对时不必进编辑器
      urlEl.title = p.url || '';

      tr.querySelector('.run').addEventListener('click', () => runPreset(p));
      tr.querySelector('.edit').addEventListener('click', () => openEditor(p));
      tr.querySelector('.del').addEventListener('click', async () => {
        if (!confirm('删除预设 "' + (p.name || '') + '"?')) return;
        await sendMessage({ type: 'deletePreset', id: p.id });
        refreshPresets();
      });

      tb.appendChild(tr);
    });

    // 重渲染后同步全选框与「删除所选」按钮
    syncSelAll();
    updateSelBar();
  }

  async function runPreset(p) {
    const isAgg = p.extraction && p.extraction.template === 'aggregateTable';
    if (p.needsSetup && isAgg) {
      // 列映射还没配好，直接把人送到编辑器里补配置
      openEditor(p);
      setStatus('这条预设还没配置列映射，补好后再运行', 'error');
      return;
    }
    const gm = $('#globalMonth').value;
    const ext = buildExtractionFromPreset(p, gm);
    await doExtract(p.url, ext, p);
  }

  function buildExtractionFromPreset(p, globalMonth) {
    const ext = Object.assign({}, p.extraction || {});
    if (ext.template === 'aggregateTable') {
      ext.filter = ext.filter || { type: 'month', value: '' };
      const ym = globalMonth || p.defaultMonth || '';
      ext.filter = { type: 'month', value: ym };
    }
    return ext;
  }

  // 「＋ 新增预设任务」：进编辑器，不带任何既有预设（否则会覆盖上一条）
  $('#btnNewPreset').addEventListener('click', () => openEditor(null));

  // === 批量新增：在新标签页打开「预设名 + URL」组合批量录入页 ===
  // 用户在该页把 Excel 里的三列（# / 预设名 / URL）整块粘贴 → 确认导入。
  // 侧边栏不直接处理粘贴内容，导入完成后靠 storage.onChanged 自动刷新列表。
  $('#btnBatchAdd').addEventListener('click', async () => {
    const r = await sendMessage({ type: 'openBatchImport' });
    if (!r || !r.ok) setStatus('打开批量录入页失败', 'error');
  });

  // 批量录入页在独立标签里写 storage（经 background upsert），
  // 这里监听变化自动刷新两个列表，用户切回侧边栏就能看到新预设（状态「待配置」）。
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local' || !changes.presets) return;
      refreshPresets();
      refreshMultiList();
    });
  } catch (e) { /* 沙箱/旧环境无此 API 时忽略 */ }

  // === 预设编辑器（内嵌聚合表列探测向导）===

  // editorState.preset 为 null 表示「新增」；否则是正在编辑的那条（保存时复用其 id）
  let editorState = { columns: [], preset: null, pickedSelector: '' };
  let editingPresetId = '';

  function savedEditorColumnMap() {
    const p = editorState.preset;
    return (p && p.extraction && p.extraction.columnMap) || {};
  }

  function syncEditorTemplate() {
    const tpl = $('#editorTemplate').value;
    $('#editorSelectorRow').classList.toggle('hidden', tpl !== 'custom');
    // 非聚合模板没有表格可探测，把整段向导收起来
    $('#editorAggSection').classList.toggle('hidden', tpl !== 'aggregateTable');
  }
  $('#editorTemplate').addEventListener('change', syncEditorTemplate);

  function openEditor(preset) {
    switchTab('presets');
    const p = preset || null;
    const ext = (p && p.extraction) || {};

    editorState = { columns: [], preset: p, pickedSelector: '' };
    editingPresetId = p ? (p.id || '') : '';

    $('#editorTitle').textContent = p
      ? ('编辑：' + (p.name || '(无名称)'))
      : '新增预设任务';
    $('#editorName').value = p ? (p.name || '') : '';
    $('#editorUrl').value = p ? (p.url || '') : '';
    $('#editorTemplate').value = ext.template || (p ? 'title' : 'aggregateTable');
    $('#editorSelector').value = ext.selector || '';
    $('#editorDiag').classList.add('hidden');
    $('#editorPreviewOut').classList.add('hidden');
    $('#editorPreviewOut').textContent = '';

    // 列下拉先按「已保存的映射」铺好，这样不重新探测也能看清/微调现有配置
    renderColumns([]);
    const cm = savedEditorColumnMap();
    if (!ROLES.some((p) => cm[p[1]])) {
      // 全新/未配置的预设：先只露「探测」那一段，别一上来就甩四个空下拉
      $('#editorResult').classList.add('hidden');
    }
    $('#editorMonth').value = (ext.filter && ext.filter.value)
      || $('#globalMonth').value
      || currentMonthValue();

    syncEditorTemplate();
    showEditorView();
    if (p && p.needsSetup) {
      setStatus('这条预设还没配置列映射，点「开始探测列」读取列头', 'error');
    } else {
      setStatus(p ? '编辑中，改完点「仅保存」或「保存并运行」' : '填好名称与 URL 后点「开始探测列」', 'ok');
    }
  }

  $('#btnEditorBack').addEventListener('click', () => {
    editingPresetId = '';
    editorState.preset = null;
    showListView();
    setStatus('', '');
  });
  $('#btnEditorCancel').addEventListener('click', () => $('#btnEditorBack').click());

  // 用当前已打开的标签页：只负责把地址填进「目标 URL」输入框，
  // 后续探测/试算一律按输入框里的 URL 打开对应页面（登录态在同一浏览器内共享）。
  $('#btnEditorUseTab').addEventListener('click', async () => {
    const r = await sendMessage({ type: 'getCurrentTab' });
    if (!r || !r.tabId || !r.url) { setStatus('没拿到当前标签页', 'error'); return; }
    $('#editorUrl').value = r.url;
    setStatus('已填入当前标签页地址，探测/试算会打开该 URL 对应的页面', 'ok');
  });

  // 四个列角色：[下拉选择器, columnMap 里的键]
  const ROLES = [
    ['#editorColProject', 'project'],
    ['#editorColMd', 'md'],
    ['#editorColMdConfirm', 'mdConfirm'],
    ['#editorColDate', 'date'],
  ];

  function roleValue(key) {
    const pair = ROLES.find((p) => p[1] === key);
    const el = pair ? $(pair[0]) : null;
    return el ? String(el.value || '').trim() : '';
  }

  // 已知的期望列名：优先用当前下拉已选中的，其次用被编辑预设里已填好的。
  // 用于让探测优先命中「表头对得上」的 frame。
  function knownEditorColumns() {
    const picked = ROLES.map((p) => roleValue(p[1])).filter(Boolean);
    if (picked.length > 0) return picked;

    const cm = savedEditorColumnMap();
    return ROLES.map((p) => cm[p[1]]).filter(Boolean);
  }

  $('#btnEditorInspect').addEventListener('click', async () => {
    const url = $('#editorUrl').value.trim();
    if (!url) { setStatus('请先填「目标 URL」，或点旁边的「用当前标签页」带过来', 'error'); return; }
    setStatus('正在打开页面并遍历所有框架探测列…', 'pending');
    $('#editorDiag').classList.add('hidden');
    $('#editorResult').classList.add('hidden');

    let r;
    try {
      r = await sendMessage({
        type: 'inspect',
        url,
        tableSelector: editorState.pickedSelector || '',
        expectedColumns: knownEditorColumns(),
      });
    } catch (e) {
      setStatus('探测失败：' + (e.message || e), 'error');
      return;
    }

    if (!r || r.error) {
      const code = (r && r.error) || 'unknown';
      let msg = '探测失败：' + friendlyError(code);
      // 探测在等待预算内没等到表格 → 多半是 iframe 渲染慢（重试通常就好了）
      if (r && r.waited && r.waited.timedOut) {
        msg += '（等待时间内页面表格没出现，多半是 iframe 加载慢——请重试一次）';
      }
      setStatus(msg, 'error');
      if (r && r.diagnosis) renderDiagnosis(r.diagnosis);
      return;
    }

    renderColumns(r.headers || []);
    const frameLabel = r.frameId != null && r.frameId !== 0 ? `（iframe frameId=${r.frameId}）` : '（主框架）';
    $('#editorFoundMeta').textContent =
      `匹配到 ${r.rowCount} 行数据 ${frameLabel}  ·  扫描 ${r.framesScanned || 1} 个框架`
      + (r.matched ? `  ·  容器 ${r.matched.selector}` : '');
    setStatus('列已读取，请点选对应角色', 'ok');
  });

  // 诊断页面结构
  $('#btnEditorDiagnose').addEventListener('click', async () => {
    const url = $('#editorUrl').value.trim();
    if (!url) { setStatus('请先填「目标 URL」，或点旁边的「用当前标签页」带过来', 'error'); return; }
    setStatus('正在诊断页面结构…', 'pending');
    let r;
    try {
      r = await sendMessage({ type: 'diagnose', url });
    } catch (e) {
      setStatus('诊断失败：' + (e.message || e), 'error');
      return;
    }
    if (!r || r.error) {
      setStatus('诊断失败：' + ((r && r.error) || 'unknown'), 'error');
      return;
    }
    renderDiagnosis(r.diagnosis);
    setStatus('诊断完成，见下方结构报告', 'ok');
  });

  function friendlyError(code) {
    const map = {
      no_table_found: '未找到任何表格（已扫描页面所有框架）',
      no_data_rows: '找到表格但没有数据行',
      no_headers_found: '找到表格但读不出列头',
      selector_not_matched: '指定的表选择器没有匹配到元素',
      invalid_selector: '表选择器语法无效',
      selector_timeout: '等待表格出现超时（页面可能加载很慢或需要登录）',
      not_logged_in: '未登录（请先在浏览器里登录后再试）',
      missing_presets: '没有勾选或找不到要汇总的预设',
      preset_needs_setup: '预设尚未配置列映射（请先编辑该预设配好列）',
      nothing_to_merge: '所有源都没有返回可用数据，无法合并',
      restricted_page: '该页面不允许插件注入（chrome:// 或扩展页）',
      load_timeout: '页面加载超时',
      inspect_timeout: '探测超时',
      extract_timeout: '提取超时（页面加载太慢或表格行数过多）',
      // 以下三个理论上已被执行器的「补注入 + 重试」吸收；
      // 若仍然出现，说明目标 frame 始终无法注入（例如沙箱 iframe），需要手动指定表选择器。
      runtime_not_loaded: '目标框架里没能挂载抓取脚本（已自动补注入重试）；'
        + '请把下方诊断报告发我，或改用「用当前标签页」重试',
      frame_inject_failed: '无法向目标框架注入脚本（可能是沙箱 iframe）',
      frame_gone: '目标 frame 在抓取过程中被页面重建了，请重试',
      extractors_not_loaded: '提取器未加载，请重新加载扩展后再试',
      tab_create_failed: '无法打开目标标签页',
      no_result: '脚本没有返回结果，请重试',
      missing_url: '缺少目标 URL',
      missing_extraction: '缺少提取配置',
      inspect_failed: '探测失败',
      extract_failed: '提取失败',
      diagnose_failed: '诊断失败',
    };
    return map[code] || code;
  }

  function renderDiagnosis(diag) {
    const box = $('#editorDiag');
    if (!diag) { box.classList.add('hidden'); return; }

    const frames = (diag.frames || []).map((f) => {
      const cands = (f.candidates || []).slice(0, 4).map((c) =>
        `<li>[${escapeHtml(c.type)}] <code>${escapeHtml(c.preview ? c.preview.selector : '')}</code>
         → 可读行 ${c.readableRows}${c.firstRow && c.firstRow.length ? '：' + escapeHtml(c.firstRow.join(' | ').slice(0, 80)) : ''}</li>`
      ).join('');
      const sugs = (f.suggestions || []).slice(0, 5).map((s) =>
        `<li><code class="pick" data-sel="${escapeHtml(s.selector)}">${escapeHtml(s.selector)}</code>（命中 ${s.count} 个）</li>`
      ).join('');
      const ifr = (f.iframeSrcs || []).map((i) =>
        `<li><code>${escapeHtml(typeof i === 'string' ? i : i.src)}</code></li>`
      ).join('');

      return `
        <div class="diag-frame">
          <div class="diag-title">框架 frameId=${f.frameId}  ${f.frameId === 0 ? '(主框架)' : ''}</div>
          <div class="diag-line">URL: ${escapeHtml(f.url || '(未知)')}</div>
          <div class="diag-line">标题: ${escapeHtml(f.title || '(空)')}</div>
          <div class="diag-line">表格 ${f.tableCount} 个 · role=grid ${f.roleGridCount} 个 · role=row ${f.roleRowCount} 个 · iframe ${f.iframeCount} 个 · 正文 ${f.bodyTextLength} 字</div>
          ${cands ? '<div class="diag-sub">候选容器</div><ul class="diag-list">' + cands + '</ul>' : ''}
          ${sugs ? '<div class="diag-sub">可用选择器（点击可填入）</div><ul class="diag-list">' + sugs + '</ul>' : ''}
          ${ifr ? '<div class="diag-sub">内嵌 iframe</div><ul class="diag-list">' + ifr + '</ul>' : ''}
          ${f.bodyTextPreview ? '<div class="diag-preview">' + escapeHtml(f.bodyTextPreview) + '</div>' : ''}
        </div>
      `;
    }).join('');

    box.innerHTML = `
      <div class="diag-head">页面结构诊断（已扫描 ${diag.frameCount || 0} 个框架）</div>
      ${frames || '<div class="hint">没有拿到任何框架信息。</div>'}
      <div class="hint">哪个框架里有「可读行 &gt; 0」的容器，就点下方「可用选择器」里它的那条（会自动记住），再点「开始探测列」按它重新探测。表格迟迟探测不到多半是 iframe 加载慢 —— 自动重扫两轮都不行时，稍等几秒再点一次「开始探测列」。</div>
    `;
    box.classList.remove('hidden');

    // 点击候选选择器即记住，重新探测时优先用它定位表格（表单里不再有手填输入框）
    $$('#editorDiag .pick').forEach((el) => {
      el.addEventListener('click', () => {
        editorState.pickedSelector = el.dataset.sel || '';
        setStatus('已记录选择器「' + editorState.pickedSelector + '」，点「开始探测列」按它重新探测', 'ok');
      });
    });
  }

  // 列下拉的可选项 = 探测到的列头 ∪ 已保存的映射值。
  // 后者不能少：已配好的预设在不重新探测的情况下也要能把现有映射显示出来。
  function columnOptions() {
    const all = [];
    const push = (v) => { if (v && all.indexOf(v) < 0) all.push(v); };
    editorState.columns.forEach(push);
    const cm = savedEditorColumnMap();
    ['project', 'md', 'mdConfirm', 'date'].forEach((k) => push(cm[k]));
    return all;
  }

  function renderColumns(cols) {
    if (cols && cols.length) editorState.columns = cols;

    // 先把当前选中的值记下来：下面重建 options 时（真实浏览器里）
    // select 的选中项会回到第一项，重建后再读就只剩空值了。
    const picked = {};
    ROLES.forEach((p) => { picked[p[1]] = roleValue(p[1]); });

    const chips = editorState.columns.map((c) => `<span class="chip">${escapeHtml(c)}</span>`).join('');
    $('#editorColumns').innerHTML = chips || '<span class="hint">未读取到列头（可点「开始探测列」，或直接配置下面的列角色）</span>';

    const all = columnOptions();
    const opts = ['<option value="">— 无 —</option>']
      .concat(all.map((c) => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`))
      .join('');
    ROLES.forEach((p) => { $(p[0]).innerHTML = opts; });

    // 启发式：含"项目"/"project" → project；含"md"+确认 → md / mdConfirm；
    // 含"日期"/"date"/Year Month → date
    const lc = editorState.columns.map((c) => ({ raw: c, low: String(c || '').toLowerCase() }));
    const found = (re) => lc.find((c) => re.test(c.raw));
    const heur = {
      project: found(/project|项目|任务|task|工作/i),
      md: found(/^md$/i) || found(/man.?days?/i),
      mdConfirm: found(/confirm/i),
      date: found(/date|日期|month|月份|年|月|时间/i),
    };

    // 手动已选的 > 预设里存的 > 启发式。重新探测不能把用户手点的选择冲掉。
    const cm = savedEditorColumnMap();
    ROLES.forEach((p) => {
      const key = p[1];
      const h = heur[key] ? heur[key].raw : '';
      const want = picked[key] || cm[key] || h || '';
      $(p[0]).value = want && all.indexOf(want) >= 0 ? want : '';
    });

    $('#editorResult').classList.remove('hidden');
  }

  function buildEditorExtraction() {
    const tpl = $('#editorTemplate').value;
    if (tpl !== 'aggregateTable') {
      const ext = { template: tpl };
      if (tpl === 'custom') ext.selector = $('#editorSelector').value.trim();
      return ext;
    }
    return {
      template: 'aggregateTable',
      columnMap: {
        project: roleValue('project'),
        md: roleValue('md'),
        mdConfirm: roleValue('mdConfirm'),
        date: roleValue('date'),
      },
      filter: { type: 'month', value: $('#editorMonth').value || '' },
      groupBy: 'project',
      sumFields: ['md', 'mdConfirm'],
    };
  }

  // 试算预览：用当前列映射跑一次，不保存
  $('#btnEditorPreview').addEventListener('click', async () => {
    const url = $('#editorUrl').value.trim();
    const md = roleValue('md');
    const mdConfirm = roleValue('mdConfirm');
    if (!md || !mdConfirm) { setStatus('请先点选 MD 列与 MD Confirm 列', 'error'); return; }
    if (!url) { setStatus('请填 URL', 'error'); return; }

    setStatus('试算中…', 'pending');
    const ext = buildEditorExtraction();
    try {
      const r = await sendMessage({ type: 'extract', url, extraction: ext });
      $('#editorPreviewOut').classList.remove('hidden');
      if (r && r.error) {
        setStatus('试算失败：' + friendlyError(r.error), 'error');
        $('#editorPreviewOut').textContent = JSON.stringify(r, null, 2);
        return;
      }
      const t = (r && r.total) || {};
      setStatus(`试算成功：命中 ${t.rows || 0} 行，MD=${t.md || 0}，MD Confirm=${t.mdConfirm || 0}`, 'ok');
      $('#editorPreviewOut').textContent = JSON.stringify({
        total: r.total,
        byProject: r.byProject,
        filter: r.filter,
        raw: r.raw,
      }, null, 2);
    } catch (e) {
      setStatus('试算失败：' + (e.message || e), 'error');
    }
  });

  async function saveEditor(runAfter) {
    const name = $('#editorName').value.trim();
    const url = $('#editorUrl').value.trim();
    const tpl = $('#editorTemplate').value;
    if (!name || !url) { setStatus('请填「预设名称」与「目标 URL」', 'error'); return; }

    const ext = buildEditorExtraction();
    if (tpl === 'custom' && !ext.selector) {
      setStatus('「自定义选择器」模板需要填选择器', 'error');
      return;
    }
    // 聚合表：没选够列就标成「待配置」——允许先存基础信息，之后回来补探测，
    // 免得为了记住一条 URL 被迫当场把列配完。
    const needsSetup = ext.template === 'aggregateTable'
      ? !(ext.columnMap.md && ext.columnMap.mdConfirm)
      : false;

    const preset = {
      id: editingPresetId,
      name,
      url,
      extraction: ext,
      // 「默认月份」输入框已按需求移除：沿用既有值（老数据兼容），运行时以顶部全局月份为准
      defaultMonth: (editorState.preset && editorState.preset.defaultMonth) || '',
      needsSetup,
    };

    const saved = await sendMessage({ type: 'upsertPreset', preset });
    const savedPreset = (saved && saved.preset) || preset;
    editingPresetId = savedPreset.id || '';
    editorState.preset = savedPreset;

    await refreshPresets();
    // 主流程是批量：刚配好的预设直接勾进「多源汇总」，切过去就能跑批量
    await refreshMultiList(savedPreset.id ? [savedPreset.id] : []);
    showListView();

    if (needsSetup) {
      setStatus('已保存。还没选「MD / MD Confirm」列，运行会被跳过', 'error');
      return;
    }
    setStatus(runAfter ? '已保存，开始运行…' : '已保存', 'ok');
    if (!runAfter) return;

    const gm = $('#globalMonth').value;
    await doExtract(savedPreset.url, buildExtractionFromPreset(savedPreset, gm), savedPreset);
  }

  $('#btnEditorSave').addEventListener('click', () => saveEditor(false));
  $('#btnEditorSaveRun').addEventListener('click', () => saveEditor(true));

  // === 标签 B：多源汇总 ===

  // 勾选状态在内存里保留：点「刷新列表」不会再把手动勾好的清空。
  // 批量任务通常要在「预设编辑」和「多源汇总」之间来回切，每次刷新都丢勾选很烦。
  const multiChecked = new Set();

  // autoCheckIds：刚在编辑器里保存成功的预设，直接勾上，省一步手点
  async function refreshMultiList(autoCheckIds) {
    const r = await sendMessage({ type: 'listPresets' });
    const presets = (r && r.presets) || [];
    const aggPresets = presets.filter(
      (p) => p.extraction && p.extraction.template === 'aggregateTable'
    );
    const auto = new Set(autoCheckIds || []);

    // 预设被删掉后，残留的勾选要一并清掉
    const alive = new Set(aggPresets.map((p) => p.id));
    Array.from(multiChecked).forEach((id) => { if (!alive.has(id)) multiChecked.delete(id); });

    const ul = $('#multiList');
    ul.innerHTML = '';
    $('#multiEmpty').classList.toggle('hidden', aggPresets.length > 0);

    aggPresets.forEach((p) => {
      const li = document.createElement('li');
      li.className = 'multi-item';
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.value = p.id;
      cb.id = 'multiCb_' + p.id;
      cb.checked = multiChecked.has(p.id) || auto.has(p.id);
      if (cb.checked) multiChecked.add(p.id);
      cb.addEventListener('change', () => {
        if (cb.checked) multiChecked.add(p.id);
        else multiChecked.delete(p.id);
      });
      const label = document.createElement('label');
      label.htmlFor = cb.id;
      label.textContent = (p.name || '(无名称)') + (p.needsSetup ? '（待配置，将跳过）' : '');
      // 右列：各源结果（跑完汇总后由 renderMultiSources 回填到这里，不再单独占一块）
      const res = document.createElement('span');
      res.className = 'multi-result';
      li.appendChild(cb);
      li.appendChild(label);
      li.appendChild(res);
      ul.appendChild(li);
    });
  }

  // 注意：这里必须包一层函数，不能直接把 refreshMultiList 当回调——click 事件对象
  // 会被当成 autoCheckIds 传进去，而 Event 不是可迭代对象，new Set(event) 会直接抛错。
  $('#btnMultiReload').addEventListener('click', () => refreshMultiList());

  $('#btnMultiAll').addEventListener('click', () => {
    $$('#multiList input[type="checkbox"]').forEach((cb) => {
      cb.checked = true;
      multiChecked.add(cb.value);
    });
  });

  $('#btnMultiNone').addEventListener('click', () => {
    $$('#multiList input[type="checkbox"]').forEach((cb) => {
      cb.checked = false;
      multiChecked.delete(cb.value);
    });
  });

  // 各源结果写进汇总列表的右列（.multi-result），不再单独占下面一块区域
  function renderMultiSources(sources) {
    const byId = {};
    (sources || []).forEach((s) => { byId[s.presetId] = s; });
    $$('#multiList .multi-item').forEach((li) => {
      const cb = li.querySelector('input[type="checkbox"]');
      const out = li.querySelector('.multi-result');
      if (!out) return;
      const s = cb ? byId[cb.value] : null;
      if (!s) { out.textContent = ''; out.title = ''; return; }
      const r = s.result || {};
      if (r.error) {
        out.textContent = '✗ ' + friendlyError(r.error);
        out.title = out.textContent;
        out.classList.add('fail');
        out.classList.remove('ok');
      } else {
        const t = r.total || {};
        out.textContent =
          `✓ 行 ${t.rows || 0} · MD ${t.md != null ? t.md : 0} · Confirm ${t.mdConfirm != null ? t.mdConfirm : 0}`;
        out.title = '';
        out.classList.add('ok');
        out.classList.remove('fail');
      }
    });
  }

  $('#btnMultiRun').addEventListener('click', async () => {
    const ids = $$('#multiList input[type="checkbox"]:checked').map((cb) => cb.value);
    if (ids.length === 0) { setStatus('请先勾选要汇总的预设', 'error'); return; }
    const month = $('#globalMonth').value;

    // 清掉上一轮的各源结果，再开始倒计时
    $$('#multiList .multi-result').forEach((el) => { el.textContent = ''; el.title = ''; });
    const stopEta = startEta(ids.length * 15, (left) => {
      $('#multiProgress').textContent =
        `汇总抓取中：${ids.length} 个源逐个执行，预计剩余约 ${left}s…`;
    });
    setStatus('多源汇总抓取中…', 'pending');

    let r;
    try {
      r = await sendMessage({ type: 'aggregateMulti', presetIds: ids, month });
    } catch (e) {
      stopEta();
      $('#multiProgress').textContent = '';
      setStatus('汇总失败：' + (e.message || e), 'error');
      return;
    }
    stopEta();
    $('#multiProgress').textContent = '';

    if (!r || r.error) {
      setStatus('汇总失败：' + friendlyError((r && r.error) || 'unknown'), 'error');
      return;
    }

    renderMultiSources(r.sources);
    handleMerged(r.merged, r);
    setStatus(`汇总完成：${r.okSourceCount}/${r.sourceCount} 个源成功`, 'ok');

    // 结果已由 background 写入 storage；这里把入口露出来并在新标签页打开汇总页
    $('#btnMultiOpenSummary').classList.remove('hidden');
    await openSummaryPage();
  });

  async function openSummaryPage() {
    try {
      const r = await sendMessage({ type: 'openSummary' });
      if (!r || !r.ok) {
        setStatus('打开汇总页失败：' + friendlyError((r && r.error) || 'unknown'), 'error');
      }
    } catch (e) {
      setStatus('打开汇总页失败：' + (e.message || e), 'error');
    }
  }

  $('#btnMultiOpenSummary').addEventListener('click', openSummaryPage);

  function handleMerged(merged, resp) {
    if (!merged || merged.error) {
      $('#aggregateView').classList.add('hidden');
      $('#resultJson').classList.remove('hidden');
      $('#resultJson').textContent = JSON.stringify(resp, null, 2);
      return;
    }
    const meta = [];
    meta.push('多源汇总: ' + (merged.sourceCount || 0) + ' 个源');
    if (resp && resp.month) meta.push('月份: ' + fmtMonth(resp.month));
    $('#resultMeta').textContent = meta.join('  |  ');
    renderAggregate(merged);
    $('#aggregateView').classList.remove('hidden');
    $('#resultJson').classList.add('hidden');
  }

  // === 可调高度（拖右下角，记忆上次高度） ===
  //
  // 统一策略：**只调高度，不调宽度**。
  // 宽度一律交给 Chrome 侧边栏 —— 用户拖宽侧边栏时，里面所有容器（面板、列表、
  // 结果区、表格、输入框）都必须是 100% 自适应，所以这里绝不写像素宽度。
  //
  // 可调高的容器：预设列表框、结果区、多源汇总面板、预设编辑器的表单区。
  //
  // 两个必须守住的点（都是修过的坑）：
  //   1) ResizeObserver 在开始观察时会**立刻回调一次**。若此时还没应用「已保存的尺寸」，
  //      就会把默认尺寸当成用户设置写回 storage，把用户拖出来的大小冲掉 → 用 ready 门闩挡住。
  //   2) 非当前选中的标签面板是 display:none（编辑器视图未打开时同理），此时
  //      offsetWidth/offsetHeight 读出来是 0。若把 0 写回 storage，下次就变成
  //      「面板高度 0」→ 保存和恢复都要跳过不可见容器。

  const UI_SIZE_KEY = 'uiSizes';
  const LEGACY_HEIGHT_KEY = 'uiHeights';   // v1.5.0 的旧键，做一次性迁移
  const resizableEls = [];
  let uiSizeSaveTimer = null;
  let uiSizesReady = false;
  // 已存尺寸的内存副本：保存时以它为底，只覆盖「当前可测量」的容器。
  // 否则在列表里拖一下高度，会把此时不可见的编辑器/汇总面板的已存尺寸整条抹掉
  // （不是写成 0，是整个键没了），下次打开那些容器就回默认值。
  let savedSizes = {};

  function isMeasurable(el) {
    return !!(el.offsetWidth || el.offsetHeight);
  }

  // opts: { key, minH }  —— 只支持高度；宽度永远自适应
  function makeResizable(el, opts) {
    if (!el) return;
    const o = opts || {};
    const key = o.key || el.id;
    if (!key) return;

    el.classList.add('resizable');
    if (o.minH) el.style.minHeight = o.minH + 'px';
    // v1.7.0 及以前这些面板支持拖宽，会把像素宽度写进 inline style（或从 storage 恢复）。
    // 必须清掉：否则固定宽度会一直卡着，用户把侧边栏拖宽时内容不再跟随。
    el.style.width = '';
    resizableEls.push({ el, key });

    // 记录「用户真的拖过」：指针按下 → 抬起之间尺寸变了才算。
    // 没拖过的自适应容器（如结果区 height:auto 填满剩余空间）绝不能因为一次
    // 普通回流就把当时的高度固化存盘 —— 那样「自适应」就名存实亡了。
    let pressSize = null;
    el.addEventListener('pointerdown', () => {
      pressSize = { w: el.offsetWidth, h: el.offsetHeight };
    });
    el.addEventListener('pointerup', () => {
      if (pressSize && (el.offsetWidth !== pressSize.w || el.offsetHeight !== pressSize.h)) {
        el._userResized = true;
      }
      pressSize = null;
    });

    const save = () => {
      if (!uiSizesReady) return;
      if (!isMeasurable(el)) return;   // 隐藏面板：不参与保存（见上面第 2 点）
      // 没有已存尺寸、用户也没拖过 → 不固化（保持 CSS 默认/自适应行为）
      if (!savedSizes[key] && !el._userResized) return;
      clearTimeout(uiSizeSaveTimer);
      uiSizeSaveTimer = setTimeout(() => {
        const sizes = Object.assign({}, savedSizes);
        resizableEls.forEach((it) => {
          if (!isMeasurable(it.el)) return;   // 跳过并保留旧值
          sizes[it.key] = { h: it.el.offsetHeight };
        });
        savedSizes = sizes;
        try { chrome.storage.local.set({ [UI_SIZE_KEY]: sizes }); } catch (e) { /* 忽略 */ }
      }, 400);
    };

    if (typeof ResizeObserver !== 'undefined') {
      new ResizeObserver(save).observe(el);
    }
  }

  async function applySavedSizes() {
    let sizes = null;
    let legacy = null;
    try {
      const d = await chrome.storage.local.get([UI_SIZE_KEY, LEGACY_HEIGHT_KEY]);
      sizes = d[UI_SIZE_KEY] || null;
      legacy = d[LEGACY_HEIGHT_KEY] || null;
    } catch (e) { /* 忽略 */ }

    // 旧版本只存过高度：迁移一次，避免用户之前拖出来的高度被重置
    if (!sizes && legacy) {
      sizes = {};
      if (legacy.presetList) sizes.presetList = { h: legacy.presetList };
      if (legacy.resultArea) sizes.resultArea = { h: legacy.resultArea };
    }
    // v1.8.x 的 panelWizard 面板高度 = 现在的编辑器表单区高度，直接继承
    if (sizes && !sizes.presetEditor && sizes.panelWizard) {
      sizes.presetEditor = sizes.panelWizard;
    }

    savedSizes = sizes || {};

    resizableEls.forEach((it) => {
      const s = savedSizes[it.key];
      // 只恢复高度。旧数据里可能存过 w，这里一律忽略并清掉遗留的像素宽度，
      // 让面板宽度重新回到「跟随侧边栏」的状态。
      it.el.style.width = '';
      if (s && s.h) it.el.style.height = s.h + 'px';
    });
    uiSizesReady = true;
  }

  // === 通用提取与结果展示 ===

  async function doExtract(url, extraction, presetMeta, tabId) {
    // 单源抓取按最慢经验值（30s）倒计，完成后由 handleResult 覆盖状态
    const stopEta = startEta(30, (left) => setStatus(`抓取中…（预计剩余约 ${left}s）`, 'pending'));
    $('#resultJson').textContent = '';
    $('#aggregateView').classList.add('hidden');
    $('#aggSummary').innerHTML = '';
    $('#aggTable tbody').innerHTML = '';
    $('#resultMeta').textContent = '';

    try {
      const msg = { type: 'extract', url, extraction };
      if (tabId != null) msg.tabId = tabId;
      const r = await sendMessage(msg);
      stopEta();
      handleResult(r, extraction, url, presetMeta);
    } catch (e) {
      stopEta();
      setStatus('提取失败：' + (e.message || e), 'error');
    }
  }

  function handleResult(r, extraction, url, presetMeta) {
    if (!r) { setStatus('无返回', 'error'); return; }
    if (r.error) {
      setStatus('错误：' + friendlyError(r.error) + (r.message ? ' — ' + r.message : ''), 'error');
      $('#resultJson').classList.remove('hidden');
      $('#resultJson').textContent = JSON.stringify(r, null, 2);
      if (r.diagnosis) {
        // 结构报告要摆在编辑器的诊断框里（报告本身就是「改配置」的依据），
        // 所以直接把对应预设的编辑器打开再渲染报告。
        openEditor(presetMeta || { url, extraction });
        renderDiagnosis(r.diagnosis);
      }
      return;
    }
    setStatus('完成', 'ok');

    const isAgg = extraction && extraction.template === 'aggregateTable';

    // 元信息
    const meta = [];
    if (extraction && extraction.template) meta.push('模板: ' + extraction.template);
    if (url) meta.push('URL: ' + shortUrl(url));
    if (r.filter && r.filter.applied) {
      const f = r.filter.applied;
      meta.push('过滤: ' + (f.startsWith('month:') ? fmtMonth(f.slice(6)) : f));
    }
    if (r.frameUrl) meta.push('框架: ' + r.frameUrl.slice(0, 60));
    if (r.raw) {
      if (r.raw.rowCount != null) meta.push('行数: ' + r.raw.rowCount);
      if (r.raw.matchedAfterFilter != null) meta.push('命中: ' + r.raw.matchedAfterFilter);
      if (r.raw.unparseableDateRows) meta.push('未识别日期: ' + r.raw.unparseableDateRows);
      if (r.raw.truncated) meta.push('已截断');
    }
    $('#resultMeta').textContent = meta.join('  |  ');

    if (isAgg && r.byProject) {
      renderAggregate(r);
      $('#aggregateView').classList.remove('hidden');
      $('#resultJson').classList.add('hidden');
    } else {
      $('#aggregateView').classList.add('hidden');
      $('#resultJson').classList.remove('hidden');
      $('#resultJson').textContent = JSON.stringify(r, null, 2);
    }
  }

  function renderAggregate(r) {
    const sum = r.total || {};
    const sumMd = sum.md != null ? sum.md : 0;
    const sumC = sum.mdConfirm != null ? sum.mdConfirm : 0;
    const sumRows = sum.rows != null ? sum.rows : 0;
    $('#aggSummary').innerHTML = `
      <div class="card"><div class="label">匹配行数</div><div class="value">${sumRows}</div></div>
      <div class="card"><div class="label">MD 总计</div><div class="value">${sumMd}</div></div>
      <div class="card"><div class="label">MD Confirm</div><div class="value">${sumC}</div></div>
    `;
    const tb = $('#aggTable tbody');
    tb.innerHTML = '';
    (r.byProject || []).forEach((p) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${escapeHtml(p.project)}</td>
        <td>${p.rows || 0}</td>
        <td>${p.md != null ? p.md : 0}</td>
        <td>${p.mdConfirm != null ? p.mdConfirm : 0}</td>
      `;
      tb.appendChild(tr);
    });
  }

  function escapeHtml(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // === 启动 ===

  (async function init() {
    syncEditorTemplate();
    bindListFilterAndSort();
    await loadGlobalMonth();
    await refreshPresets();
    await refreshMultiList();
    makeResizable($('#presetList'), { key: 'presetList', minH: 80 });
    makeResizable($('#resultArea'), { key: 'resultArea', minH: 120 });
    makeResizable($('#panelMulti'), { key: 'panelMulti', minH: 160 });
    // 编辑器表单区：同样只调高，宽度跟随侧边栏自适应。
    // key 用 presetEditor（v1.8.x 的 panelWizard 高度会在 applySavedSizes 里继承过来）
    makeResizable($('#editorBody'), { key: 'presetEditor', minH: 160 });
    await applySavedSizes();
  })();
})();
