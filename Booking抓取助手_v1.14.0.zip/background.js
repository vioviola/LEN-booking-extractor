// background.js
// Manifest V3 service worker。
// 职责：
//   - 接收侧边栏消息 → 静默开标签 → 注入提取脚本 → 返回结果
//   - 预设 / 全局月份的读写经 lib/presets.js（PresetsStore）统一处理
//   - 首次安装注入示例预设

// 加载数据层（挂在 self.PresetsStore）与聚合器（挂在 self.Aggregator，多源汇总合并用）
// lib/summary.js 提供汇总页两表的行数据构建（自成一个数据层，挂在 self.SummaryData）
importScripts('lib/presets.js');
importScripts('lib/aggregator.js');
importScripts('lib/summary.js');

const LOAD_TIMEOUT_MS = 30000;
const EXTRACT_TIMEOUT_MS = 60000;
const INSPECT_TIMEOUT_MS = 45000;
// frame 判定轮询预算：SPA（目标平台 webresource）常在主文档 complete 之后
// 才异步创建 iframe 并渲染表格，给足时间；命中即返回，不会白等。
const FRAME_RESOLVE_TIMEOUT_MS = 20000;

// 运行时文件（顺序敏感：contentScript.js 作为桥依赖前两个 lib 已挂载）
const RUNTIME_FILES = ['lib/aggregator.js', 'lib/extractors.js', 'contentScript.js'];

// ===== 侧边栏（Side Panel）=====
// 点击工具栏图标 → 打开/关闭右侧边栏（替代旧弹窗形态）。
// 必须在顶层调用：setPanelBehavior 是持久化设置，SW 每次唤醒都要确保生效。
try {
  chrome.sidePanel
    .setPanelBehavior({ openPanelOnActionClick: true })
    .catch((e) => console.error('[bg] setPanelBehavior:', e));
} catch (e) {
  // Chrome < 114 无 sidePanel API：降级为无操作，不影响其余功能
  console.error('[bg] sidePanel 不可用:', e);
}

// ===== 生命周期 =====

chrome.runtime.onInstalled.addListener(() => {
  PresetsStore.upgradePresets()
    .then(() => PresetsStore.ensureSeed())
    .catch((e) => console.error('[bg] init presets:', e));
});
chrome.runtime.onStartup.addListener(() => {
  // 版本升级后补齐老预设的出厂配置（幂等，只跑一次）
  PresetsStore.upgradePresets().catch((e) => console.error('[bg] upgradePresets:', e));
  PresetsStore.ensureSeed().catch((e) => console.error('[bg] ensureSeed:', e));
});

// ===== 工具 =====

function timeout(ms, errorCode) {
  return new Promise((_, reject) =>
    setTimeout(() => reject(new Error(errorCode)), ms)
  );
}

// 等待指定 tab 加载完成
function waitForTabComplete(tabId, timeoutMs) {
  return new Promise((resolve) => {
    let done = false;

    const finish = (result) => {
      if (done) return;
      done = true;
      chrome.tabs.onUpdated.removeListener(listener);
      chrome.tabs.onRemoved.removeListener(onRemoved);
      clearTimeout(timer);
      resolve(result);
    };

    const listener = (updatedId, info) => {
      if (updatedId === tabId && info.status === 'complete') finish({ ok: true });
    };
    const onRemoved = (removedId) => {
      if (removedId === tabId) finish({ ok: false, error: 'tab_closed' });
    };
    const timer = setTimeout(() => finish({ ok: false, error: 'load_timeout' }), timeoutMs);

    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.onRemoved.addListener(onRemoved);

    // 可能已经完成（在 addListener 之前就 complete）
    chrome.tabs.get(tabId).then((t) => {
      if (t && t.status === 'complete') finish({ ok: true });
    }).catch(() => finish({ ok: false, error: 'tab_gone' }));
  });
}

async function safeRemoveTab(tabId) {
  try {
    await chrome.tabs.remove(tabId);
  } catch (e) { /* tab 可能已关闭 */ }
}

// 在目标页注入 lib + 桥。allFrames=true 让 iframe 内的 document 也能被找到
// （目标平台 的 webresource 常被内嵌在 iframe 中）。
// 注意：InjectionTarget 只接受 tabId / allFrames / frameIds / documentIds，
// 传入其他属性（如 MV2 时代的 matchAboutBlank）会被 Chrome 判定为 Invalid arguments，
// 导致整个注入调用失败 → 表现为 inject_failed。
async function injectRuntime(tabId, allFrames) {
  const target = { tabId };
  if (allFrames) target.allFrames = true;
  try {
    await chrome.scripting.executeScript({ target, files: RUNTIME_FILES });
    return { ok: true };
  } catch (e) {
    const msg = String(e && e.message || e);
    // chrome:// / 扩展页 / PDF 等受限页面
    if (/cannot be scripted|Cannot access|Extension manifest must request|The extensions gallery/i.test(msg)) {
      return { ok: false, error: 'restricted_page', message: msg };
    }
    // 某些 frame 注入失败（内含沙箱 iframe），只要主 frame 成功就继续；
    // 子 frame 之后由 injectRuntimeIntoFrame 按需补注入。
    if (/No frame with id|Frame with ID|all frames/i.test(msg)) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId },
          files: RUNTIME_FILES,
        });
        return { ok: true, partial: true, message: msg };
      } catch (e2) {
        return { ok: false, error: 'inject_failed', message: String(e2 && e2.message || e2) };
      }
    }
    return { ok: false, error: 'inject_failed', message: msg };
  }
}

// 只往指定的单个 frame 补注入运行时桥。
// 为什么必须有这个：SPA 常在主文档 status=complete 之后才异步创建 iframe
// （目标平台 的 webresource iframe 就是这样），此时 allFrames 注入早已执行完毕，
// 新 frame 里没有桥 → 执行 extractFn/inspectFn 时直接返回 runtime_not_loaded。
// contentScript.js 内有 `if (self.__ExtractorRuntime) return` 幂等守卫，重复注入无副作用。
async function injectRuntimeIntoFrame(tabId, frameId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId, frameIds: [frameId] },
      files: RUNTIME_FILES,
    });
    return { ok: true };
  } catch (e) {
    return { ok: false, error: 'frame_inject_failed', message: String(e && e.message || e) };
  }
}

// 在所有 frame 上跑一个函数，返回原始 InjectionResult[]（含 frameId / result）
async function execInAllFrames(tabId, fn, args, timeoutMs) {
  const run = chrome.scripting.executeScript({
    target: { tabId, allFrames: true },
    func: fn,
    args: args || [],
  });
  if (!timeoutMs) return run;
  return Promise.race([run, timeout(timeoutMs, 'exec_timeout')]);
}

// 在指定 frame 上执行 fn，并对「运行时桥缺失」自愈。
// 两种失败模式：
//   ① runtime_not_loaded —— 该 frame 是首次注入之后才被 SPA 创建的 → 就地补注入后重试一次
//   ② frame_gone         —— 该 frame 已随 SPA 重建而消失 → 原样返回，调用方退回主 frame
async function execOnFrame(tabId, frameId, fn, args, timeoutMs, errorCode) {
  const target = { tabId, frameIds: [frameId] };

  const runOnce = async () => {
    try {
      const exec = await chrome.scripting.executeScript({ target, func: fn, args: args || [] });
      return exec && exec[0] ? exec[0].result : null;
    } catch (e) {
      const msg = String(e && e.message || e);
      // frame 随导航/SPA 重建消失：具体文案随 Chrome 版本变化，这里宽松匹配
      if (/frame with id|no frame with id|was removed|no tab with id/i.test(msg)) {
        return { error: 'frame_gone', frameId, message: msg };
      }
      throw e;
    }
  };

  let payload = await Promise.race([runOnce(), timeout(timeoutMs, errorCode || 'exec_timeout')]);

  if (payload && payload.error === 'runtime_not_loaded') {
    const heal = await injectRuntimeIntoFrame(tabId, frameId);
    if (heal.ok) {
      await new Promise((r) => setTimeout(r, 150));
      payload = await Promise.race([runOnce(), timeout(timeoutMs, errorCode || 'exec_timeout')]);
    } else if (heal.message) {
      payload.injectError = heal.message;
    }
  }
  return payload;
}

// 在所有 frame 上执行 fn；只要有 frame 报「桥没加载」，就整体补注入一遍再重试一次。
// 覆盖两种情况：首次 allFrames 注入时个别 frame 失败、以及注入之后才创建的 iframe。
async function execInAllFramesWithHeal(tabId, fn, args, timeoutMs) {
  const first = await execInAllFrames(tabId, fn, args, timeoutMs);
  const missing = (first || []).filter((r) => r && r.result && r.result.error === 'runtime_not_loaded');
  if (missing.length === 0) return first;

  await injectRuntime(tabId, true);
  await new Promise((r) => setTimeout(r, 150));
  const retry = await execInAllFrames(tabId, fn, args, timeoutMs);

  const retryByFrame = new Map();
  (retry || []).forEach((r) => retryByFrame.set(r.frameId, r));

  const merged = (first || []).map((r) => {
    const better = retryByFrame.get(r.frameId);
    if (!better || !better.result) return r;
    // 重试仍缺桥、而首次是好的 → 保留首次
    if (better.result.error === 'runtime_not_loaded'
      && r.result && r.result.error !== 'runtime_not_loaded') return r;
    return better;
  });
  // 重试中才出现的 frame（例如 SPA 新建的）也带上
  (retry || []).forEach((r) => {
    if (!merged.some((m) => m.frameId === r.frameId)) merged.push(r);
  });
  return merged;
}

// 从所有 frame 的探测结果里挑「最靠谱」的那个：
//   1. 表头命中「期望列名」最多的优先（有期望列名时最可靠）
//   2. ok=true 的优先
//   3. 都有 / 都没有时，取正文最长、row 最多的 frame（避开空白 about:blank 桥页）
function pickBestProbe(results, expectedColumns) {
  const list = (results || []).filter((r) => r && r.result);
  if (list.length === 0) return null;

  const expected = (expectedColumns || []).filter(Boolean).map((c) => String(c).trim().toLowerCase());
  const hits = (r) => {
    if (expected.length === 0) return 0;
    const hs = ((r.result && r.result.headers) || []).map((h) => String(h).trim().toLowerCase());
    return expected.filter((c) => hs.indexOf(c) >= 0).length;
  };

  const score = (r) => {
    const res = r.result;
    if (!res || res.error) return -1;
    return hits(r) * 1e12 + (res.ok ? 1e9 : 0) + (res.rowCount || 0) * 1000
      + ((res.frame && res.frame.textLength) || 0);
  };

  let best = null;
  let bestScore = -Infinity;
  list.forEach((r) => {
    const s = score(r);
    if (s > bestScore) { bestScore = s; best = r; }
  });

  // 全部失败：返回信息量最大的诊断
  if (bestScore < 0) {
    let richest = null;
    list.forEach((r) => {
      const res = r.result || {};
      const d = res.diagnosis || {};
      const richness = (d.tableCount || 0) * 100 + (d.roleRowCount || 0) * 10
        + (d.iframeCount || 0) + ((d.bodyTextLength || 0) / 1000);
      if (!richest || richness > richest.richness) richest = { r, richness, frameId: r.frameId };
    });
    return richest ? richest.r : null;
  }
  return best;
}

// 打开 URL → 等加载 → 注入（含所有 iframe）→ 执行 fn → 关标签
// 注：performExtract / performInspect / performDiagnose 各自走更细的流程
// （登录检测、frame 选择、超时分层、诊断兜底），因此本通用封装不再被调用，已移除。

// 从 extraction 里取出「期望列名」（columnMap 的各列），用于 frame 判定
function expectedColumnsOf(extraction) {
  const cm = (extraction && extraction.columnMap) || {};
  return ['project', 'md', 'mdConfirm', 'date'].map((k) => cm[k]).filter(Boolean);
}

// 判定「该在哪个 frame 上干活」：
//   ① 有期望列名时，优先看哪个 frame 的表头命中列名 —— 最可靠，不受外壳页干扰
//   ② 否则主 frame 有可读表格 → 0
//   ③ 否则挑 table / role=row 最多的子 frame
//   ④ 都没有 → -1（调用方退回主 frame，让诊断信息回到主 frame 上取）
async function resolveTargetFrameId(tabId, opts) {
  const o = opts || {};
  const expected = (o.expectedColumns || []).filter(Boolean);
  const sigArgs = [{ expectedColumns: expected, tableSelector: o.tableSelector || '' }];
  const maxRounds = Math.max(1, Math.round(FRAME_RESOLVE_TIMEOUT_MS / 500));
  try {
    // 给所有 frame 一点时间把表格渲染出来（命中即返回，不会白等到超时）
    for (let i = 0; i < maxRounds; i++) {
      const sigs = await execInAllFrames(tabId, frameSignalFn, sigArgs, 10000);
      const list = (sigs || []).filter((r) => r && r.result);
      if (list.length === 0) return -1;

      // ① 列名匹配优先
      if (expected.length > 0) {
        const full = list.filter((r) => r.result.headerHits >= expected.length && r.result.bestRows > 0);
        if (full.length > 0) {
          const main = full.find((r) => r.frameId === 0);
          if (main) return 0;
          return full.sort((a, b) => b.result.bestRows - a.result.bestRows)[0].frameId;
        }
      }

      const main = list.find((r) => r.frameId === 0);
      // 主 frame 就能对上（无期望列名时退化为「有表格即可」）
      if (main && main.result.tableCount > 0 && expected.length === 0) return 0;

      // 部分命中：取命中列名最多、且确有数据行的 frame
      const partial = list
        .filter((r) => r.result.headerHits > 0 && r.result.bestRows > 0)
        .sort((a, b) => (b.result.headerHits - a.result.headerHits)
          || (b.result.bestRows - a.result.bestRows))[0];
      if (partial) return partial.frameId;

      // 没有「有数据行」的子 frame 就继续轮询等渲染，不要被「只有表头」的半个表骗走。
      // Element UI 拆表结构的表头表常先于表体出现，此时 tableCount>0 但 bestRows=0，
      // 过早锁定会导致提取报 no_data_rows（表体稍后渲染完，诊断里却看得到数据）。
      // 实在等不到（循环结束）再退回旧行为：见循环后的兜底。
      const bestSub = list
        .filter((r) => r.frameId !== 0 && r.result.tableCount > 0 && r.result.bestRows > 0)
        .sort((a, b) => (b.result.tableCount * 1000 + b.result.bestRows * 100 + b.result.roleRowCount * 10 + b.result.textLength)
          - (a.result.tableCount * 1000 + a.result.bestRows * 100 + a.result.roleRowCount * 10 + a.result.textLength))[0];
      if (bestSub) return bestSub.frameId;

      // 没有 table 但有 role=row（虚拟表格）也算有货
      const rowSub = list
        .filter((r) => r.frameId !== 0 && r.result.roleRowCount > 0)
        .sort((a, b) => b.result.roleRowCount - a.result.roleRowCount)[0];
      if (rowSub) return rowSub.frameId;

      // 主 frame 完全空白（about:blank 空壳）→ 挑正文最长的子 frame
      const mainEmpty = !main || main.result.textLength < 20;
      const anyone = list.filter((r) => r.frameId !== 0 && r.result.textLength > 50)[0];
      if (mainEmpty && anyone) return anyone.frameId;

      if (i < maxRounds - 1) await new Promise((r) => setTimeout(r, 500));
    }
  } catch (e) {
    console.warn('[bg] resolveTargetFrameId:', e && e.message);
  }
  return -1;
}

// ===== 业务动作 =====

// 本 frame 的「有没有货」信号（在所有 frame 上执行）。
// 必须自给自足：桥没注入成功时也要能报出「表头命中期望列名」，否则 frame 判定会退化到
// 「谁的 table 多」——而 目标平台 外壳页自己也有 grid，会挑错 frame，
// 最终在正确的 frame 上执行时又因为没有桥而返回 runtime_not_loaded（死循环式的错判）。
function frameSignalFn(opts) {
  const o = opts || {};
  const expected = (o.expectedColumns || []).filter(Boolean);
  const low = (v) => String(v == null ? '' : v).trim().toLowerCase();

  try {
    const text = (document.body && (document.body.innerText || document.body.textContent)) || '';
    const sig = {
      url: (document.location && document.location.href) || '',
      title: document.title || '',
      textLength: text.trim().length,
      tableCount: document.querySelectorAll('table').length,
      roleRowCount: document.querySelectorAll('[role="row"]').length,
      bodyLength: document.body ? (document.body.innerHTML || '').length : 0,
      hasRuntime: !!self.__ExtractorRuntime,
      headers: [],
      headerHits: 0,
      matchedColumns: [],
      bestRows: 0,
    };

    // ① 桥在 → 用它给出的精确结果（能正确处理 el-table 表头/表体拆成两个 <table> 的情况）
    if (sig.hasRuntime) {
      const rich = self.__ExtractorRuntime.frameSignal(o);
      if (rich) return Object.assign(sig, rich, { hasRuntime: true });
    }

    // ② 桥不在 → 自己按原始 DOM 粗算，保证 frame 判定不受注入成败影响。
    //    这里刻意「宽进」：只要文档里出现过这些表头文字就算命中，
    //    因为 frame 判定只需要一个比较信号，不需要精确的表格定位。
    const headerTexts = [];
    document.querySelectorAll('th, [role="columnheader"]').forEach((el) => {
      const t = (el.innerText || el.textContent || '').trim();
      if (t) headerTexts.push(t);
    });
    sig.headers = headerTexts.slice(0, 16);
    const headerSet = headerTexts.map(low);
    sig.matchedColumns = expected.filter((c) => headerSet.indexOf(low(c)) >= 0);
    sig.headerHits = sig.matchedColumns.length;

    let rows = 0;
    document.querySelectorAll('table').forEach((t) => {
      const n = t.querySelectorAll('tbody tr').length || t.querySelectorAll('tr').length;
      if (n > rows) rows = n;
    });
    sig.bestRows = rows;
    return sig;
  } catch (e) {
    return {
      url: '', title: '', textLength: 0, tableCount: 0, roleRowCount: 0, bodyLength: 0,
      hasRuntime: false, headers: [], headerHits: 0, matchedColumns: [], bestRows: 0,
      signalError: String(e && e.message || e),
    };
  }
}

// 登录页检测（在目标页上下文执行）
function detectLoginFn() {
  return self.__ExtractorRuntime ? self.__ExtractorRuntime.detectLoginPage() : false;
}

// 执行提取（在目标页上下文执行）
async function extractFn(extraction) {
  if (!self.__ExtractorRuntime) return { error: 'runtime_not_loaded' };
  try {
    const r = await self.__ExtractorRuntime.run(extraction);
    if (r && r.error) r.frameUrl = location.href;
    return r;
  } catch (e) {
    return { error: 'extract_threw', message: String(e && e.message || e) };
  }
}

// 探测表格结构（在目标页上下文执行，参数为对象）
async function inspectFn(opts) {
  const o = opts || {};
  if (!self.__ExtractorRuntime) return { error: 'runtime_not_loaded' };
  try {
    const r = await self.__ExtractorRuntime.inspect(
      o.tableSelector || '',
      o.waitForSelector || '',
      o.timeoutMs || 20000,
      o.expectedColumns || []
    );
    if (r && r.error) r.frameUrl = location.href;
    return r;
  } catch (e) {
    return { error: 'inspect_threw', message: String(e && e.message || e) };
  }
}

// 页面结构诊断（在目标页上下文执行）
function diagnoseFn() {
  if (!self.__ExtractorRuntime) return { error: 'runtime_not_loaded' };
  try {
    const d = self.__ExtractorRuntime.diagnose();
    d.frameUrl = location.href;
    return d;
  } catch (e) {
    return { error: 'diagnose_threw', message: String(e && e.message || e) };
  }
}

// 在原始标签页上做提取（供侧边栏传 tabId 用，避免再次导航丢失页面状态）
async function performExtract({ url, extraction, tabId }) {
  if (!extraction || !extraction.template) return { error: 'missing_extraction' };
  if (tabId == null && !url) return { error: 'missing_url' };

  // 有现成 tabId：直接用它
  if (tabId != null) {
    const r = await extractOnTab(tabId, extraction);
    if (r && !r.error) return r;
    if (r && r.error !== 'no_result' && r.error !== 'extract_failed') return r;
    if (!url) return r;
  }

  let tab;
  try {
    tab = await chrome.tabs.create({ url, active: false });
  } catch (e) {
    return { error: 'tab_create_failed', message: String(e && e.message || e) };
  }
  const newTabId = tab.id;

  try {
    const ready = await waitForTabComplete(newTabId, LOAD_TIMEOUT_MS);
    if (!ready.ok) return { error: ready.error };
    return await extractOnTab(newTabId, extraction);
  } finally {
    await safeRemoveTab(newTabId);
  }
}

// 在某个已存在的标签页上完成「注入 → 登录检测 → 在合适的 frame 提取」
async function extractOnTab(tabId, extraction) {
  try {
    const inj = await injectRuntime(tabId, true);
    if (!inj.ok) return { error: inj.error, message: inj.message };

    // 登录检测：任一 frame 判定为登录页即视为未登录
    try {
      const logins = await execInAllFrames(tabId, detectLoginFn, [], 8000);
      const mainLogin = (logins || []).find((r) => r && r.frameId === 0 && r.result === true);
      const subLogin = (logins || []).filter((r) => r && r.frameId !== 0 && r.result === true);
      // 主 frame 是登录页，或所有子 frame 都是登录页 → 判定未登录
      const allLogin = subLogin.length > 0 && subLogin.length === (logins || []).filter((r) => r.frameId !== 0).length;
      if (mainLogin || allLogin) return { error: 'not_logged_in' };
    } catch (e) { /* 登录检测失败不阻断提取 */ }

    const frameId = await resolveTargetFrameId(tabId, {
      expectedColumns: expectedColumnsOf(extraction),
      tableSelector: extraction.tableSelector || '',
    });
    let targetFrameId = frameId >= 0 ? frameId : 0;

    // 提取（内部含 waitForSelector 轮询，故给更长超时）。
    // execOnFrame 会在该 frame 缺桥时就地补注入后重试一次。
    let payload = await execOnFrame(
      tabId, targetFrameId, extractFn, [extraction], EXTRACT_TIMEOUT_MS, 'extract_timeout'
    );

    // 该 frame 已随 SPA 重建而消失 → 退回主 frame 再试一次
    if (payload && payload.error === 'frame_gone' && targetFrameId !== 0) {
      targetFrameId = 0;
      payload = await execOnFrame(
        tabId, 0, extractFn, [extraction], EXTRACT_TIMEOUT_MS, 'extract_timeout'
      );
    }

    // 选中的 frame 没数据 → 在所有 frame 里再找一遍，把有数据的结果带回来。
    // 注意必须包含 runtime_not_loaded / frame_gone：否则「注入晚于 iframe 创建」
    // 这种情况会直接把裸错误码丢给用户，连诊断都不给（v1.2.0 的实际表现）。
    const unusable = !payload || payload.error === 'no_table_found'
      || payload.error === 'no_data_rows' || payload.error === 'no_headers_found'
      || payload.error === 'runtime_not_loaded' || payload.error === 'frame_gone';
    if (unusable) {
      const all = await execInAllFramesWithHeal(tabId, extractFn, [extraction], EXTRACT_TIMEOUT_MS);
      const good = (all || []).find((r) => r && r.result
        && !r.result.error && (r.result.total || r.result.byProject));
      if (good) payload = good.result;
      else if (payload && payload.error) {
        // 仍然失败：附上诊断，帮用户定位
        const diag = await diagnoseAcrossFrames(tabId);
        payload.diagnosis = diag;
      }
    }

    return payload == null ? { error: 'no_result' } : payload;
  } catch (e) {
    const msg = String(e && e.message || e);
    if (msg === 'extract_timeout') return { error: 'extract_timeout' };
    return { error: 'extract_failed', message: msg };
  }
}

// 汇总所有 frame 的诊断信息，供侧边栏展示
async function diagnoseAcrossFrames(tabId) {
  try {
    // 走自愈版本：个别 frame 缺桥时先补注入，否则诊断报告会是空的
    const results = await execInAllFramesWithHeal(tabId, diagnoseFn, [], 15000);
    const frames = (results || [])
      .filter((r) => r && r.result && !r.result.error)
      .map((r) => Object.assign({ frameId: r.frameId }, r.result));
    // 排序：信息量大的在前（主 frame 优先展示）
    frames.sort((a, b) => (a.frameId === 0 ? -1 : 0) - (b.frameId === 0 ? -1 : 0));
    return { frameCount: frames.length, frames: frames.slice(0, 5) };
  } catch (e) {
    return { error: 'diagnose_failed', message: String(e && e.message || e) };
  }
}

async function performInspect({ url, tableSelector, waitForSelector, timeoutMs, tabId, expectedColumns }) {
  if (!url && tabId == null) return { error: 'missing_url' };

  let tab;
  let ownTab = false;
  try {
    if (tabId != null) {
      tab = { id: tabId };
    } else {
      tab = await chrome.tabs.create({ url, active: false });
      ownTab = true;
    }
  } catch (e) {
    return { error: 'tab_create_failed', message: String(e && e.message || e) };
  }

  const tabIdActual = tab.id;
  try {
    if (ownTab) {
      const ready = await waitForTabComplete(tabIdActual, LOAD_TIMEOUT_MS);
      if (!ready.ok) return { error: ready.error };
    }

    const inj = await injectRuntime(tabIdActual, true);
    if (!inj.ok) return { error: inj.error, message: inj.message };

    const opts = {
      tableSelector: tableSelector || '',
      waitForSelector: waitForSelector || '',
      timeoutMs: timeoutMs || 20000,
      expectedColumns: expectedColumns || [],
    };

    // 「这一轮里有没有 frame 探到能用的表」——ok 且有数据行才算数。
    // 只有列头没有数据行（rowCount=0）对聚合向导毫无用处，不能当成功收货；
    // 有期望列名时还要求列名命中 —— 否则先渲染好的汇总表（列名对不上）
    // 会被误当成可用结果（实测页面同时存在明细表和汇总表两个表格组）。
    const expLower = (expectedColumns || []).filter(Boolean).map((c) => String(c).trim().toLowerCase());
    const usable = (b) => {
      const res = b && b.result;
      if (!res || res.error || !res.ok || (res.rowCount || 0) <= 0) return false;
      if (expLower.length === 0) return true;
      const hs = (res.headers || []).map((h) => String(h).trim().toLowerCase());
      return expLower.some((c) => hs.indexOf(c) >= 0);
    };

    // 主 frame 有表格就地探测；否则在所有 frame 里挑最靠谱的结果。
    // 走自愈版本：SPA 新建的 iframe 首次注入时不存在，缺桥会让整轮探测全废。
    const results = await execInAllFramesWithHeal(tabIdActual, inspectFn, [opts], INSPECT_TIMEOUT_MS);
    let best = pickBestProbe(results, expectedColumns);

    // 首轮没有任何 frame 探到可用表格 → 大概率是 webresource iframe
    // 在注入之后才创建 / 渲染完（Dynamics 实测：诊断时表格已在，探测时全空）。
    // 等一小会儿把所有 frame 重扫一遍（晚出现的 frame 这次会被扫到），再挑一次。
    if (!usable(best)) {
      await new Promise((r) => setTimeout(r, 2500));
      const opts2 = Object.assign({}, opts, {
        timeoutMs: Math.min(opts.timeoutMs || 20000, 12000),
      });
      const second = await execInAllFramesWithHeal(tabIdActual, inspectFn, [opts2], INSPECT_TIMEOUT_MS);
      const best2 = pickBestProbe(second, expectedColumns);
      if (usable(best2)) {
        best = best2;
        best.rescanned = true;
      }
    }

    if (best && best.result && !best.result.error) {
      const r = best.result;
      r.frameId = best.frameId;
      if (!r.waited) r.waited = {};
      r.framesScanned = (results || []).length;
      return r;
    }

    // 全部失败 → 返回诊断
    const payload = (best && best.result) || { error: 'no_table_found' };
    payload.diagnosis = await diagnoseAcrossFrames(tabIdActual);
    return payload;
  } catch (e) {
    const msg = String(e && e.message || e);
    if (msg === 'inspect_timeout') return { error: 'inspect_timeout' };
    return { error: 'inspect_failed', message: msg };
  } finally {
    if (ownTab) await safeRemoveTab(tabIdActual);
  }
}

// 只做诊断，不要求找到表格（用户点「诊断页面结构」时用）
async function performDiagnose({ url, tabId }) {
  if (!url && tabId == null) return { error: 'missing_url' };

  let tab;
  let ownTab = false;
  try {
    if (tabId != null) tab = { id: tabId };
    else { tab = await chrome.tabs.create({ url, active: false }); ownTab = true; }
  } catch (e) {
    return { error: 'tab_create_failed', message: String(e && e.message || e) };
  }

  const tabIdActual = tab.id;
  try {
    if (ownTab) {
      const ready = await waitForTabComplete(tabIdActual, LOAD_TIMEOUT_MS);
      if (!ready.ok) return { error: ready.error };
    }
    const inj = await injectRuntime(tabIdActual, true);
    if (!inj.ok) return { error: inj.error, message: inj.message };

    // 给页面一点渲染时间再诊断
    await new Promise((r) => setTimeout(r, 2000));
    const diag = await diagnoseAcrossFrames(tabIdActual);
    diag.tabId = tabIdActual;
    diag.url = url || '';
    return { ok: true, diagnosis: diag };
  } catch (e) {
    return { error: 'diagnose_failed', message: String(e && e.message || e) };
  } finally {
    if (ownTab) await safeRemoveTab(tabIdActual);
  }
}

// 多预设汇总：逐个运行所选预设（结构相同的多个 URL），把各自聚合结果按项目合并。
// 顺序执行（目标平台页面较重，并发开多个后台标签容易互相拖慢）。
async function performAggregateMulti({ presetIds, month }) {
  const ids = Array.isArray(presetIds) ? presetIds.filter(Boolean) : [];
  if (ids.length === 0) return { error: 'missing_presets' };

  const all = await PresetsStore.listPresets();
  const chosen = ids.map((id) => all.find((p) => p.id === id)).filter(Boolean);
  if (chosen.length === 0) return { error: 'missing_presets' };

  const sources = [];
  for (const p of chosen) {
    if (p.needsSetup) {
      sources.push({ presetId: p.id, name: p.name, url: p.url, result: { error: 'preset_needs_setup' } });
      continue;
    }
    const ext = PresetsStore.buildExtraction(p, month);
    const r = await performExtract({ url: p.url, extraction: ext });
    sources.push({ presetId: p.id, name: p.name, url: p.url, result: r });
  }

  const okResults = sources
    .map((s) => s.result)
    .filter((r) => r && !r.error && r.byProject);
  const merged = okResults.length > 0
    ? Aggregator.mergeAggregates(okResults)
    : { error: 'nothing_to_merge', message: '所有源都没有返回可用数据' };

  const payload = {
    ok: !merged.error,
    month: month || '',
    presetIds: chosen.map((p) => p.id),
    sourceCount: chosen.length,
    okSourceCount: okResults.length,
    generatedAt: new Date().toISOString(),
    sources,
    merged,
  };

  // 落 storage：独立汇总页（新标签）靠它取数，也便于重开标签后不丢结果。
  // 失败源的诊断里带 bodyTextPreview，先瘦身再存，否则多源全失败时会撑大 storage。
  try {
    await chrome.storage.local.set({ [SummaryData.SUMMARY_KEY]: SummaryData.slimPayload(payload) });
  } catch (e) {
    console.error('[bg] 写入汇总结果失败:', e);
  }

  return payload;
}

// 在独立标签页打开汇总页（summary.html）。
// 用 tabs.create 打开扩展自身页面无需 web_accessible_resources（那只管网页侧访问）。
async function openSummaryPage() {
  const url = chrome.runtime.getURL('summary.html');
  try {
    const tab = await chrome.tabs.create({ url });
    return { ok: true, tabId: tab ? tab.id : null, url };
  } catch (e) {
    return { ok: false, error: 'tab_create_failed', message: String(e && e.message || e) };
  }
}

// 在独立标签页打开「预设名 + URL」组合批量录入页（batch-import.html）。
// 侧边栏「批量新增」按钮的入口：粘贴/解析/确认导入都在那个页面完成。
async function openBatchImportPage() {
  const url = chrome.runtime.getURL('batch-import.html');
  try {
    const tab = await chrome.tabs.create({ url });
    return { ok: true, tabId: tab ? tab.id : null, url };
  } catch (e) {
    return { ok: false, error: 'tab_create_failed', message: String(e && e.message || e) };
  }
}

// 批量录入页「确认导入」：逐条建预设（统一在这里去重 + 校验，页面只管收集行）。
// 新预设一律 needsSetup=true（状态「待配置」——URL 先记下来，列映射之后进编辑器探测补齐）。
// 行里带了编号（# 列）就写进 preset.no，供列表排序用。
async function bulkImportPresets({ items }) {
  const list = Array.isArray(items) ? items : [];
  if (list.length === 0) return { error: 'missing_items' };

  const all = await PresetsStore.listPresets();
  const seen = new Set(all.map((p) => String(p.url || '')));
  let added = 0;
  let skipped = 0;
  for (const it of list) {
    const url = String((it && it.url) || '').trim();
    const name = String((it && it.name) || '').trim();
    if (!url || !/^https?:\/\//i.test(url) || seen.has(url)) { skipped++; continue; }
    seen.add(url);
    const preset = {
      name: name || PresetsStore.hostOf(url),
      url,
      extraction: { template: 'aggregateTable', columnMap: {} },
      defaultMonth: '',
      needsSetup: true,
    };
    const no = Number(it && it.no);
    if (Number.isFinite(no) && no >= 1) preset.no = Math.round(no);
    await PresetsStore.upsertPreset(preset);
    added++;
  }
  return { ok: true, added, skipped };
}

// ===== 消息分发 =====

const handlers = {
  extract: (msg) => performExtract({
    url: msg.url,
    extraction: msg.extraction,
    tabId: msg.tabId,
  }),

  inspect: (msg) => performInspect({
    url: msg.url,
    tableSelector: msg.tableSelector,
    waitForSelector: msg.waitForSelector,
    timeoutMs: msg.timeoutMs,
    tabId: msg.tabId,
    expectedColumns: msg.expectedColumns,
  }),

  diagnose: (msg) => performDiagnose({ url: msg.url, tabId: msg.tabId }),

  aggregateMulti: (msg) => performAggregateMulti({ presetIds: msg.presetIds, month: msg.month }),

  openSummary: () => openSummaryPage(),

  openBatchImport: () => openBatchImportPage(),

  bulkImportPresets: (msg) => bulkImportPresets(msg),

  // 汇总页直接读取上次结果（不经消息通道，避免 SW 冷启动时拿不到）
  async getSummary() {
    const d = await chrome.storage.local.get(SummaryData.SUMMARY_KEY);
    return { payload: d[SummaryData.SUMMARY_KEY] || null };
  },

  async getCurrentTab() {
    const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
    return {
      tabId: t ? t.id : null,
      url: t ? t.url : '',
      title: t ? t.title : '',
    };
  },

  async listPresets() {
    return { presets: await PresetsStore.listPresets() };
  },

  async upsertPreset(msg) {
    const saved = await PresetsStore.upsertPreset(msg.preset);
    return { preset: saved };
  },

  async deletePreset(msg) {
    await PresetsStore.deletePreset(msg.id);
    return { ok: true };
  },

  async getGlobalMonth() {
    return { globalMonth: await PresetsStore.getGlobalMonth() };
  },

  async setGlobalMonth(msg) {
    const v = await PresetsStore.setGlobalMonth(msg.value);
    return { ok: true, globalMonth: v };
  },
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const type = msg && msg.type;
  const handler = handlers[type];

  if (!handler) {
    sendResponse({ error: 'unknown_message', type });
    return false;
  }

  Promise.resolve()
    .then(() => handler(msg))
    .then((result) => sendResponse(result))
    .catch((e) => {
      console.error('[bg] handler error for', type, e);
      sendResponse({ error: 'handler_failed', type, message: String(e && e.message || e) });
    });

  return true; // 保持通道开放以异步响应
});
