// batch-import.js
// 「预设名 + URL」组合批量录入页（独立标签页，从侧边栏「批量新增」打开）。
//
// 流程：Excel 里复制三列（# / 预设名 / URL）→ 粘贴到文本框 → 自动解析成
// 可编辑表格（TSV 解析用 lib/presets.js 的纯函数 parsePresetTsv）→
// 用户核对/修改 → 点「确认导入」→ 经 background 批量建预设（状态「待配置」）。
// 侧边栏监听 storage 变化自动刷新，无需手动操作。

(function () {
  'use strict';

  function $(sel) { return document.querySelector(sel); }

  function escapeHtml(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function setHint(el, text, kind) {
    el.textContent = text || '';
    el.className = 'hint' + (kind ? ' ' + kind : '');
  }

  // === 解析：粘贴文本 → 表格行 ===

  function parseAndRender() {
    const text = $('#pasteBox').value || '';
    const items = self.PresetsStore.parsePresetTsv(text);
    renderRows(items);
    if (!text.trim()) {
      setHint($('#parseHint'), '');
    } else if (items.length === 0) {
      setHint($('#parseHint'), '没有解析出「预设名 + URL」组合：URL 列需要是 http(s) 链接', 'err');
    } else {
      setHint($('#parseHint'), `已解析 ${items.length} 行，可在表格里直接修改`, 'ok');
    }
  }

  // 渲染可编辑表格。每行三个输入格：# / 预设名 / URL。
  function renderRows(items) {
    const tb = $('#batchBody');
    tb.innerHTML = '';
    if (!items.length) {
      tb.innerHTML = '<tr><td colspan="3" class="empty-tip">还没有内容 —— 把 Excel 里的「# / 预设名 / URL」三列粘贴到上方文本框</td></tr>';
      return;
    }
    items.forEach((it, i) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td class="col-no"><input type="number" class="b-no" min="1" step="1" /></td>
        <td class="col-name"><input type="text" class="b-name" /></td>
        <td><input type="text" class="b-url" spellcheck="false" /></td>
      `;
      tr.querySelector('.b-no').value = it.no != null ? it.no : (i + 1);
      tr.querySelector('.b-name').value = it.name || '';
      tr.querySelector('.b-url').value = it.url || '';
      // URL 明显不是链接的行标红提示（确认导入时会被跳过）
      if (!/^https?:\/\//i.test(it.url || '')) tr.classList.add('row-bad');
      tb.appendChild(tr);
    });
  }

  // === 导入：收集表格行 → 逐条建预设（经 background 统一去重/校验） ===

  async function confirmImport() {
    const rows = Array.from($('#batchBody').querySelectorAll('tr'))
      .filter((tr) => tr.querySelector('input.b-url'));
    const items = rows.map((tr) => ({
      no: parseInt(tr.querySelector('.b-no').value, 10),
      name: tr.querySelector('.b-name').value.trim(),
      url: tr.querySelector('.b-url').value.trim(),
    })).filter((it) => it.url);

    const invalid = items.filter((it) => !/^https?:\/\//i.test(it.url));
    if (items.length === 0) {
      setHint($('#importStatus'), '表格里没有可导入的行：先在上方粘贴内容', 'err');
      return;
    }
    if (invalid.length === items.length) {
      setHint($('#importStatus'), '所有行的 URL 都不是 http(s) 链接，请检查粘贴内容', 'err');
      return;
    }

    const btn = $('#btnConfirmImport');
    btn.disabled = true;
    setHint($('#importStatus'), '导入中…');
    try {
      const resp = await new Promise((resolve, reject) => {
        try {
          chrome.runtime.sendMessage({ type: 'bulkImportPresets', items }, (r) => {
            const err = chrome.runtime.lastError;
            if (err) reject(new Error(err.message));
            else resolve(r);
          });
        } catch (e) { reject(e); }
      });
      if (!resp || resp.error) {
        setHint($('#importStatus'), '导入失败：' + ((resp && resp.error) || 'unknown'), 'err');
        return;
      }
      const parts = [`成功新增 ${resp.added} 条（状态「待配置」）`];
      if (resp.skipped > 0) parts.push(`跳过 ${resp.skipped} 条（重复 URL 或 URL 无效）`);
      setHint($('#importStatus'), parts.join('，') + '。回到侧边栏即可看到。', 'ok');
      // 导入成功后清掉已导入的行，避免在同一页重复点导入
      if (resp.added > 0) {
        $('#pasteBox').value = '';
        renderRows([]);
        setHint($('#parseHint'), '');
      }
    } catch (e) {
      setHint($('#importStatus'), '导入失败：' + (e.message || e), 'err');
    } finally {
      btn.disabled = false;
    }
  }

  // === 接线 ===

  // 粘贴/输入即自动解析（节流 300ms），也可点「重新解析」
  let parseTimer = null;
  $('#pasteBox').addEventListener('input', () => {
    clearTimeout(parseTimer);
    parseTimer = setTimeout(parseAndRender, 300);
  });
  $('#pasteBox').addEventListener('paste', () => {
    clearTimeout(parseTimer);
    parseTimer = setTimeout(parseAndRender, 300);
  });
  $('#btnParse').addEventListener('click', parseAndRender);
  $('#btnConfirmImport').addEventListener('click', confirmImport);
})();
